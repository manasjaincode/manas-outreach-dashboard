import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from './Authcontext.jsx';

const ProtectedRoute = () => {
    const { isAuthenticated, isLoading } = useAuth(); // isAuthenticated is now a boolean state

    if (isLoading) {
        return null; // Don't render content until auth status is known
    }

    if (!isAuthenticated) {
        return <Navigate to="/referfriend" replace />;
    }
    return <Outlet />;
};

export default ProtectedRoute;