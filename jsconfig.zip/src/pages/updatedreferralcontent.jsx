import React, { useState } from 'react';
import { Share2, Copy, X } from 'lucide-react';

import acml from "../assets/img/acml.png";
import whatsappIcon from '../assets/img/icon/whatsapp.png';
import facebookIcon from '../assets/img/icon/fb.png';
import gmailIcon from '../assets/img/icon/email.png';
import linkdinIcon from '../assets/img/icon/linkdin.png';
import instagramIcon from '../assets/img/icon/instagram.png';
import twitterIcon from '../assets/img/icon/x.png';
import telegramIcon from '../assets/img/icon/telegram.png';
import messagesIcon from '../assets/img/icon/freechat.png';
import Coinbg from '../assets/img/Coinbg.png';

const ReferralContent = ({ showHeader = true, isNested = false }) => {
    const [referralCode, setReferralCode] = useState('MMVYC328');
    const [referralLink, setReferralLink] = useState('https://acml.link.example/loginusingmyreferrallink');
    const [copiedReferralCode, setCopiedReferralCode] = useState(false);
    const [showShareModal, setShowShareModal] = useState(false);

    const handleCopyReferralCode = () => {
        navigator.clipboard.writeText(referralCode).then(() => {
            setCopiedReferralCode(true);
            setTimeout(() => setCopiedReferralCode(false), 2000);
        });
    };

    const handleCopyReferralLink = () => {
        navigator.clipboard.writeText(referralLink).then(() => {
            console.log('Referral link copied!');
        });
    };

    const socialPlatforms = [
        { name: 'WhatsApp', icon: whatsappIcon, action: () => console.log('Share on WhatsApp') },
        { name: 'Facebook', icon: facebookIcon, action: () => console.log('Share on Facebook') },
        { name: 'Gmail', icon: gmailIcon, action: () => console.log('Share on Gmail') },
        { name: 'Linkdin', icon: linkdinIcon, action: () => console.log('Share on Linkdin') },
        { name: 'Instagram', icon: instagramIcon, action: () => console.log('Share on Instagram') },
        { name: 'Twitter', icon: twitterIcon, action: () => console.log('Share on Twitter') },
        { name: 'Telegram', icon: telegramIcon, action: () => console.log('Share on Telegram') },
        { name: 'Messages', icon: messagesIcon, action: () => console.log('Share via Messages') },
    ];

    return (
        <div className={`
            px-4 py-4 sm:px-12 sm:py-10 pb-4 sm:pb-28
            max-w-full lg:max-w-[1150px] xl:max-w-[1300px] mx-auto relative z-10
            ${isNested ? 'mt-0' : 'bg-white rounded-lg shadow-md mt-6 border border-gray-200'}
        `}>
            {/* Earn 20% Brokerage Banner - Adjusted for responsiveness and compactness */}
            <div className="bg-[rgba(52,179,80,0.12)] border border-green-200 rounded-lg px-2 py-2 mb-4 sm:mb-8 shadow-sm flex items-center justify-start text-left max-w-full mx-auto w-full">
                <img
                    src={Coinbg}
                    alt="Coins"
                    className="w-8 h-8 sm:w-14 sm:h-14 flex-shrink-0 mr-2 sm:mr-3"
                />
                <p className="text-sm sm:text-base font-medium leading-tight text-[#434343]">
                    Earn <span className="font-bold text-[#34B350]">₹300*</span> when your friend opens an account using your referral link!
                </p>
            </div>

            {/* Main content layout adjusted for mobile-first for single-screen view */}
            <div className="flex flex-col items-center justify-center space-y-4 sm:space-y-6 lg:grid lg:grid-cols-2 lg:gap-8 lg:space-y-0">

                {/* Right Section (QR Image) - Moved up and made more compact for mobile order */}
                <div className="w-full max-w-[200px] sm:max-w-[320px] mx-auto flex justify-center order-1 lg:order-2">
                    <div className="bg-white p-3 sm:p-6 rounded-lg shadow-md border border-gray-200 w-full">
                        <img
                            src={acml}
                            alt="Arihant Capital QR"
                            className="w-full h-auto object-contain"
                            onError={(e) => {
                                e.target.onerror = null;
                                e.target.src = 'https://placehold.co/200x200/cccccc/000000?text=QR+Code+Not+Found';
                            }}
                        />
                    </div>
                </div>

                {/* Left Section - Adjusted order and compactness for mobile */}
                <div className="w-full max-w-[320px] sm:max-w-[360px] mx-auto text-center space-y-3 sm:space-y-6 px-2 sm:px-0 order-2 lg:order-1 pt-0 sm:pt-14">
                    {/* Ask a friend to scan your referral QR code... */}
                    <div>
                        <h2 className="text-base sm:text-xl font-medium text-gray-800 mb-1 sm:mb-2 leading-snug">
                            Ask a friend to scan your<br className="sm:hidden" />
                            referral QR code and register with <span className="font-medium">Arihant Capital</span>
                        </h2>
                        <p className="text-sm sm:text-xl text-gray-600 mb-2 sm:mb-4 tracking-wider">
                            and start earning money every time your friend trades
                        </p>
                        <div className="w-10 h-0.5 bg-green-500 mx-auto mb-4 sm:mb-6"></div>

                        {/* Share QR Button */}
                        <button
                            onClick={() => setShowShareModal(true)}
                            className="bg-green-500 hover:bg-green-600 text-white px-5 sm:px-8 py-1.5 sm:py-3 rounded-full flex items-center justify-center space-x-1 sm:space-x-2 mx-auto transition-colors duration-200 shadow-md hover:shadow-lg"
                        >
                            <Share2 className="w-4 h-4 sm:w-5 sm:h-5" />
                            <span className="font-medium text-sm sm:text-base">Share QR</span>
                        </button>
                    </div>

                    {/* Copy Referral Code Section */}
                    <div className="pt-2 sm:pt-6 px-2 sm:px-0 max-w-xs sm:max-w-sm mx-auto">
                        <p className="text-xs sm:text-base text-gray-600 mb-2 sm:mb-4 whitespace-nowrap">
                            You can also copy & share the referral link
                        </p>
                        <div className="flex items-center bg-purple-100 border border-purple-200 rounded px-3 py-2 mb-2 sm:mb-4">
                            <span className="flex-1 text-purple-800 text-xs sm:text-sm font-mono font-medium tracking-wider truncate">
                                {referralCode}
                            </span>
                            <button
                                onClick={handleCopyReferralCode}
                                className="text-purple-600 hover:text-purple-800 transition-colors duration-200 ml-1 p-1"
                                title="Copy referral code"
                            >
                                <Copy className="w-4 h-4 sm:w-5 sm:h-5" />
                            </button>
                        </div>
                        {copiedReferralCode && (
                            <p className="text-green-600 text-xs sm:text-sm mb-2 sm:mb-4 text-center animate-fade-in">
                                Referral code copied to clipboard!
                            </p>
                        )}
                        {/* Terms & Conditions */}
                        <p className="text-[0.6rem] sm:text-sm text-gray-500 text-center break-words">
                            By referring a friend you agree to our{' '}
                            <button className="text-green-600 hover:text-green-700 underline focus:outline-none focus:ring-2 focus:ring-green-300 rounded-sm">
                                Terms & Conditions
                            </button>
                        </p>
                    </div>
                </div>
            </div>

            {/* Share QR Modal (no changes needed here for layout, as it's a separate overlay) */}
            {showShareModal && (
                <div className="fixed inset-0 bg-black/30 backdrop-blur-sm flex items-center justify-center z-50 px-4 animate-fade-in">
                    <div className="bg-white rounded-2xl p-5 sm:p-6 w-full max-w-md sm:max-w-lg mx-auto relative">
                        <div className="flex justify-between items-center mb-5">
                            <h3 className="text-lg sm:text-xl font-medium text-gray-800">Share referral QR</h3>
                            <button
                                onClick={() => setShowShareModal(false)}
                                className="text-gray-400 hover:text-gray-600 focus:outline-none focus:ring-2 focus:ring-gray-300 rounded-full"
                            >
                                <X className="w-6 h-6" />
                            </button>
                        </div>

                        <div className="grid grid-cols-4 gap-4 mb-6">
                            {socialPlatforms.map((platform, index) => (
                                <button
                                    key={index}
                                    className="w-14 h-14 sm:w-16 sm:h-16 flex flex-col items-center justify-center hover:scale-105 transition-transform group"
                                    title={`Share on ${platform.name}`}
                                    onClick={platform.action}
                                >
                                    <img
                                        src={platform.icon}
                                        alt={platform.name}
                                        className="w-10 h-10 sm:w-12 sm:h-12 object-contain rounded-lg"
                                    />
                                    <span className="text-xs text-gray-600 mt-1 group-hover:text-gray-800">{platform.name}</span>
                                </button>
                            ))}
                        </div>

                        <div className="flex items-center mb-6">
                            <div className="flex-1 h-px bg-gray-200"></div>
                            <span className="px-4 text-gray-400 text-xs sm:text-sm">OR</span>
                            <div className="flex-1 h-px bg-gray-200"></div>
                        </div>

                        <div className="text-center px-2 sm:px-0">
                            <p className="text-gray-600 mb-4 text-xs sm:text-sm">You can also copy & share the referral link</p>
                            <div className="flex items-center bg-purple-50 border border-purple-200 rounded-lg px-3 py-2">
                                <span className="flex-1 text-purple-800 text-xs sm:text-sm font-medium truncate">
                                    {referralLink}
                                </span>
                                <button
                                    onClick={handleCopyLink}
                                    className="ml-2 p-1 text-purple-600 hover:text-purple-800 focus:outline-none focus:ring-2 focus:ring-purple-300 rounded-full"
                                    title="Copy referral link"
                                >
                                    <Copy className="w-4 h-4" />
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default ReferralContent;