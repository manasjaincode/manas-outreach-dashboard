import React, { useState, useEffect, useCallback, useRef } from "react";
import { Link, useNavigate } from "react-router-dom";
// useAuth is commented out as authentication state will not be managed via API login here
// import { useAuth } from "../Authcontext.jsx";
import { ruppee } from "../assets/img/img";
import { useLoader } from "../App.jsx";
// apiClient is commented out as we're focusing on frontend only
// import apiClient from "../shared/apiClient.jsx";
import ToastMessage from "../ToastMessage.jsx";
import { FaRupeeSign } from 'react-icons/fa';

export default function OtpVerificationPage() {
    const navigate = useNavigate();
    // useAuth is commented out as authentication state will not be managed via API login here
    // const { isAuthenticated, isLoading: isAuthContextLoading } = useAuth();
    const { showLoader, hideLoader, isLoading: isGlobalLoading } = useLoader();

    const IDLE_TIMEOUT_MS = 10 * 60 * 1000;

    const [state, setState] = useState({
        seconds: 120,
        isActive: true,
        otp: '',
        clientCode: null,
        // tempAuthTokenForOtp is commented out as it's for API calls
        // tempAuthTokenForOtp: null,
        toast: {
            message: '',
            type: '',
            isVisible: false,
        },
    });

    const { seconds, isActive, otp, clientCode, toast } = state; // Removed tempAuthTokenForOtp

    const lastActivityTimeRef = useRef(Date.now());
    const idleTimerIntervalRef = useRef(null);

    const formatTime = useCallback((totalSeconds) => {
        const minutes = Math.floor(totalSeconds / 60);
        const remainingSeconds = totalSeconds % 60;
        return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
    }, []);

    const showToast = useCallback((message, type) => {
        setState(prevState => ({
            ...prevState,
            toast: { message, type, isVisible: true },
        }));
    }, []);

    const hideToast = useCallback(() => {
        setState(prevState => ({
            ...prevState,
            toast: { message: '', type: '', isVisible: false },
        }));
    }, []);

    const resetIdleTimer = useCallback(() => {
        lastActivityTimeRef.current = Date.now();
    }, []);

    const handleIdleTimeout = useCallback(() => {
        console.log("Idle timeout reached. Redirecting to /referfriend.");
        // Clear all session storage relevant to the previous flow
        sessionStorage.removeItem('authToken');
        sessionStorage.removeItem('currentClientCodeForOtp');
        sessionStorage.removeItem('otpExpirationTime');
        // Clear track status specific session storage
        sessionStorage.removeItem('isTrackStatusFlow'); // <--- ADD THIS LINE
        navigate('/referfriend', { replace: true });
        showToast("You were inactive for too long. Please re-enter your details.", "error");
    }, [navigate, showToast]);

    useEffect(() => {
        let interval = null;
        if (isActive && seconds > 0) {
            interval = setInterval(() => {
                setState(prevState => ({ ...prevState, seconds: prevState.seconds - 1 }));
            }, 1000);
        } else if (seconds === 0 && isActive) {
            setState(prevState => ({ ...prevState, isActive: false }));
            clearInterval(interval);
        }
        return () => clearInterval(interval);
    }, [isActive, seconds]);

    useEffect(() => {
        const activityEvents = ['mousemove', 'keydown', 'click', 'scroll'];
        window.scrollTo(0, 0); // Keep this for initial scroll
        activityEvents.forEach(event => {
            window.addEventListener(event, resetIdleTimer);
        });

        idleTimerIntervalRef.current = setInterval(() => {
            if (Date.now() - lastActivityTimeRef.current > IDLE_TIMEOUT_MS) {
                clearInterval(idleTimerIntervalRef.current);
                handleIdleTimeout();
            }
        }, 1000);

        return () => {
            activityEvents.forEach(event => {
                window.removeEventListener(event, resetIdleTimer);
            });
            if (idleTimerIntervalRef.current) {
                clearInterval(idleTimerIntervalRef.current);
            }
        };
    }, [resetIdleTimer, handleIdleTimeout, IDLE_TIMEOUT_MS]);

    useEffect(() => {
        // This useEffect block for redirection based on authentication is commented out
        // because useAuth login is removed in this frontend-only version.
        // If you uncomment useAuth and the login function, this logic can be re-enabled.
        /*
        if (isAuthContextLoading) {
            return;
        }
        if (isAuthenticated) {
            navigate('/dashboard', { replace: true });
            return;
        }
        */

        const storedClientCode = sessionStorage.getItem('currentClientCodeForOtp');
        // const storedTempAuthToken = sessionStorage.getItem('authToken'); // Commented out
        const storedOtpExpirationTime = sessionStorage.getItem('otpExpirationTime');

        // Changed logic: only check for storedClientCode since authToken is no longer a strict dependency for frontend flow
        if (!storedClientCode) {
            showToast("Session expired or invalid. Please generate OTP again.", "error");
            navigate('/referfriend', { replace: true });
            // Ensure session storage is cleared if navigation occurs due to missing clientCode
            sessionStorage.removeItem('authToken');
            sessionStorage.removeItem('currentClientCodeForOtp');
            sessionStorage.removeItem('otpExpirationTime');
            sessionStorage.removeItem('isTrackStatusFlow'); // <--- ADD THIS LINE
        } else {
            let initialSeconds = 120;
            let initialIsActive = true;

            if (storedOtpExpirationTime) {
                const timeRemaining = Math.max(0, Math.floor((parseInt(storedOtpExpirationTime) - Date.now()) / 1000));
                initialSeconds = timeRemaining;
                initialIsActive = timeRemaining > 0;
            }
            
            setState(prevState => ({
                ...prevState,
                clientCode: storedClientCode,
                // tempAuthTokenForOtp: storedTempAuthToken, // Commented out
                seconds: initialSeconds,
                isActive: initialIsActive,
            }));
            resetIdleTimer();
        }
    }, [navigate, /* isAuthenticated, isAuthContextLoading, */ showToast, resetIdleTimer]); // Removed isAuthenticated, isAuthContextLoading from dependencies

    const handleResendOtp = useCallback(async () => {
        if (!clientCode) {
            showToast("Error: Client code missing to resend OTP.", "error");
            return;
        }

        hideToast();
        showLoader();
        resetIdleTimer();

        // --- Frontend-only Logic (API call commented out) ---
        // Simulate a network request delay for UI feedback
        setTimeout(() => {
            hideLoader();
            // Simulate a successful resend response
            const otpValiditySeconds = 120; // Default or simulate new validity
            const newOtpExpirationTime = Date.now() + (otpValiditySeconds * 1000);

            setState(prevState => ({
                ...prevState,
                seconds: otpValiditySeconds,
                isActive: true,
                otp: '', // Clear OTP field on resend
                // tempAuthTokenForOtp: 'simulated_new_token', // Simulate a new token if needed for subsequent steps
            }));
            sessionStorage.setItem('otpExpirationTime', newOtpExpirationTime.toString());
            showToast('Simulated OTP resent successfully. Please check your mobile.', "success");
        }, 1500); // Simulate 1.5 seconds of loading
        // --- End Frontend-only Logic ---


        /* --- Original API Call (Commented out) ---
        try {
            const response = await apiClient.post('/ReferralPartner/Login/Generateotpbyclientcode', { ClientCode: clientCode });

            if (response.data.Status === true) {
                const otpValiditySeconds = parseInt(response.data.Token?.expirytime) || 120;
                const newOtpExpirationTime = Date.now() + (otpValiditySeconds * 1000);

                setState(prevState => ({
                    ...prevState,
                    seconds: otpValiditySeconds,
                    isActive: true,
                    otp: '',
                    tempAuthTokenForOtp: response.data.Token?.access_token || prevState.tempAuthTokenForOtp
                }));
                if(response.data.Token?.access_token) {
                    sessionStorage.setItem('authToken', response.data.Token.access_token);
                }
                sessionStorage.setItem('otpExpirationTime', newOtpExpirationTime.toString());

                showToast(response.data.message || 'OTP resent successfully. Please check your mobile.', "success");
            } else {
                showToast(response.data.message || 'Failed to resend OTP. Please try again.', "error");
                console.error("Resend OTP failed:", response.data.message);
            }
        } catch (error) {
            console.error('API Error during resend OTP:', error);
            let errorMessage = 'An error occurred while resending OTP. Please try again.';
            if (error.response) {
                errorMessage = error.response.data.message || `Server responded with status ${error.response.status}. Please try again.`;
            }
            showToast(errorMessage, "error");
        } finally {
            hideLoader();
        }
        */
    }, [clientCode, showLoader, hideLoader, showToast, resetIdleTimer, hideToast]); // Added hideToast to dependencies

    const handleOtpVerification = useCallback(async (e) => {
        e.preventDefault();

        if (!clientCode) { // Removed tempAuthTokenForOtp check as it's no longer used for verification logic
            console.error("OTP Verification: Client code missing for verification.");
            showToast("Error: Cannot verify OTP. Missing client code.", "error");
            hideLoader(); // Ensure loader is hidden if an error occurs early
            return;
        }
        if (otp.length !== 6 || !/^\d+$/.test(otp)) {
            showToast("Please enter a valid 6-digit OTP.", "error");
            return;
        }

        hideToast();
        showLoader();
        resetIdleTimer();

        // --- Frontend-only Logic (API call commented out) ---
        // Simulate a network request delay for UI feedback
        setTimeout(() => {
            hideLoader();
            // Simulate successful verification and redirection
            showToast('OTP verified successfully! Redirecting...', "success");
            sessionStorage.removeItem('currentClientCodeForOtp');
            sessionStorage.removeItem('otpExpirationTime');

            // Determine redirect path based on session storage flag
            const redirectToDashboardTS = sessionStorage.getItem('isTrackStatusFlow');
            
            // Remove the flag after use
            sessionStorage.removeItem('isTrackStatusFlow');

            // Simulate login if useAuth's login function were active.
            // For a pure frontend view, this might just be a navigate.
            // If you enable useAuth, uncomment the next line and provide dummy data.
            // login('dummy_full_auth_token', { name: 'Simulated User' }, 86400); 
            
            // **Conditional Redirection Logic - UPDATED TO REDIRECT TO /dashboard-rs BY DEFAULT**
            if (redirectToDashboardTS) {
                navigate('/dashboard-ts', { replace: true }); // Redirect to DashboardTS
            } else {
                navigate('/dashboard-rs', { replace: true }); // <--- UPDATED: DEFAULT TO REFERRAL DASHBOARD
            }
        }, 1500); // Simulate 1.5 seconds of loading
        // --- End Frontend-only Logic ---


        /* --- Original API Call (Commented out) ---
        try {
            const headers = { 'Authorization': `Bearer ${tempAuthTokenForOtp}` };
            const response = await apiClient.post('/ReferralPartner/Login/ClientOtpValidate',
                { ClientCode: clientCode, OTP: otp },
                { headers: headers }
            );

            if (response.data.Status === true && response.data.Token?.access_token) {
                sessionStorage.setItem('ClientName', response.data.Token.ClientName);
                login(response.data.Token.access_token, response.data.UserInfo, response.data.Token.expires_in || 86400);
                sessionStorage.removeItem('currentClientCodeForOtp');
                sessionStorage.removeItem('otpExpirationTime');
                // Check if this was a track status login
                const redirectToDashboardTS = sessionStorage.getItem('isTrackStatusFlow');
                sessionStorage.removeItem('isTrackStatusFlow'); // Remove the flag after use

                showToast('OTP verified successfully! Redirecting...', "success");

                if (redirectToDashboardTS) {
                    navigate('/dashboardTS', { replace: true });
                } else {
                    navigate('/dashboard', { replace: true });
                }
            } else {
                console.error("OTP Verification failed:", response.data.message);
                let displayMessage = response.data.message;

                if (displayMessage && displayMessage.includes('erong')) {
                    displayMessage = displayMessage.replace('erong', 'wrong');
                }
                
                if (displayMessage === 'OTP Validate Validation Failure') {
                    displayMessage = 'Incorrect OTP. Please check and re-enter.'; 
                }
                
                showToast(displayMessage || 'Incorrect OTP. Please check and re-enter.', "error");
            }
        } catch (error) {
            console.error('API Error during OTP verification:', error);
            let errorMessage = 'An error occurred during OTP verification. Please try again.';
            if (error.response) {
                console.error("OTP API Error Response Data:", error.response.data);
                console.error("OTP API Error Response Status:", error.response.status);
                errorMessage = error.response.data.message || `Server responded with status ${error.response.status}. Please try again.`;
                
                if (errorMessage.includes('erong')) {
                    errorMessage = errorMessage.replace('erong', 'wrong');
                }
            } else if (error.request) {
                errorMessage = 'No response from server. Check your internet connection or try again later.';
            }
            showToast(errorMessage, "error");
        } finally {
            hideLoader();
        }
        */
    }, [clientCode, otp, navigate, showLoader, hideLoader, showToast, hideToast, resetIdleTimer]); // Removed login from dependencies

    const isVerifyButtonDisabled = otp.length !== 6 || !/^\d+$/.test(otp);

    // If you enable useAuth, uncomment this block
    /*
    if (isAuthContextLoading) {
        return null;
    }
    */

    return (
        <div
            className=" bg-gray-50 relative"
            onMouseMove={resetIdleTimer}
            onKeyDown={resetIdleTimer}
            onClick={resetIdleTimer}
            onScroll={resetIdleTimer}
        >
            {toast.isVisible && (
                <ToastMessage
                    message={toast.message}
                    type={toast.type}
                    onClose={hideToast}
                />
            )}

            <div className={`
                transition-all duration-300 ease-in-out
                ${isGlobalLoading ? 'filter blur-sm brightness-75 pointer-events-none' : ''}
            `}>
                <div className="max-w-7xl mx-auto px-4 pt-20"> 
                    <div className="grid lg:grid-cols-2 gap-3 items-center min-h-[calc(90vh)]">
                        {/* Left section: Earn 1000* - Styles copied from ReferFriend LHS */}
                        <div className="flex flex-col items-center justify-center text-center w-full max-w-md ">
                            <div className="flex justify-center">
                                <img
                                    src={ruppee}
                                    alt="Coin Icon"
                                    className="w-64 md:w-80 lg:max-w-96 mb-8"
                                    onError={(e) => { e.target.onerror = null; e.target.src = 'https://placehold.co/320x320/cccccc/000000?text=Image+Not+Found'; }}
                                />
                            </div>
                            <div className="flex flex-col items-center text-center">
                                <h1 className="text-4xl sm:text-5xl font-semibold text-[#434343] flex items-baseline leading-none">
                                    <span> Earn </span>
                                    <span className="ml-1 sm:ml-2 inline-flex items-baseline" style={{ color: '#34B350' }}>
                                        <FaRupeeSign
                                            className="inline-block"
                                            style={{
                                                height: '0.85em',
                                                width: '0.85em',
                                                transform: 'translateY(0.1em)',
                                            }}
                                        />
                                        1000*
                                    </span>
                                    <p className="text-[10px] sm:text-[12px] ml-1 font-medium whitespace-nowrap text-green-600 ">(T&C Apply)</p>
                                </h1>
                                <p className="text-gray-600 text-base sm:text-lg mt-2 font-normal md:text-2xl tracking-wider text-center lg:whitespace-nowrap">
                                    When your friend opens a Referral Partner account with us.
                                </p>
                            </div>
                        </div>

                        {/* Right section: OTP Verification Form */}
                        <div className="flex justify-center lg:justify-start mt-6 lg:mt-0">
                            <div className="bg-white shadow-xl border border-gray-300 rounded-2xl 
                                p-4 pt-8 pb-10 mb-6 w-full max-w-xs mx-auto 
                                sm:p-6 sm:pt-10 sm:pb-12 sm:max-w-sm 
                                md:p-10 md:pt-16 md:pb-12 md:max-w-md 
                                lg:mb-0 lg:max-w-xl">
                                <div className="text-center mb-8">
                                    <h3 className="text-xl md:text-2xl font-medium text-gray-900 mb-2">
                                        Verify your account
                                    </h3>
                                    <p className="text-md text-gray-600">
                                        <span className="inline-block">An OTP has been shared on your registered mobile number</span>
                                    </p>
                                </div>

                                <form onSubmit={handleOtpVerification} className="space-y-4">
                                    <div>
                                        <label htmlFor="otp" className="block text-left text-gray-700 text-sm font-medium mb-2">
                                            OTP <span className="text-red-500">*</span>
                                        </label>
                                        <input
                                            type="text"
                                            id="otp"
                                            className="w-full px-4 py-3 border border-gray-300 rounded-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-colors duration-200 text-gray-900"
                                            placeholder="Enter 6-digit OTP"
                                            maxLength="6"
                                            value={otp}
                                            onChange={(e) => setState(prevState => ({ ...prevState, otp: e.target.value.replace(/\D/, '') }))}
                                            pattern="[0-9]{6}"
                                            title="Please enter a 6-digit numeric OTP."
                                            inputMode="numeric"
                                            required
                                        />
                                    </div>
                                    <div className="flex justify-center mt-8">
                                        <button
                                            type="submit"
                                            className={`
                                                w-28 max-w-xs py-5 rounded-full text-white font-semibold shadow-md transition-all duration-200 hover:shadow-lg
                                                ${isVerifyButtonDisabled
                                                    ? 'opacity-50 cursor-not-allowed'
                                                    : 'hover:bg-[#2c9146] hover:shadow-lg'
                                                }
                                            `}
                                            style={{ background: 'linear-gradient(270deg, #34B350 0%, #76D78A 100%)' }}
                                            disabled={isVerifyButtonDisabled || isGlobalLoading} 
                                        >
                                            Verify
                                        </button>
                                    </div>
                                </form>

                                <p className="mt-6 text-md text-gray-600 text-center">
                                    Did not receive the OTP?
                                    {seconds > 0 ? (
                                        <>
                                            <span className="text-green-600 font-medium ml-1">Resend OTP</span>{" "}
                                            <span className="text-black">in</span>{" "}
                                            <span className="text-green-600 font-medium">{formatTime(seconds)}</span>
                                        </>
                                    ) : (
                                        <button
                                            onClick={handleResendOtp}
                                            className="text-green-600 font-medium ml-1 hover:underline disabled:text-gray-400 disabled:no-underline disabled:cursor-not-allowed"
                                            disabled={isActive || isGlobalLoading} // Also disable if global loading
                                        >
                                            Resend OTP
                                        </button>
                                    )}
                                </p>

                                <div className="mt-6 border-t border-gray-200 w-full" />

                                <div className="flex justify-end mt-6 font-medium text-sm">
                                    <Link
                                        target="_blank"
                                        to="https://support.arihantcapital.com/support/solutions/33000138462"
                                        className="text-green-600 hover:underline"
                                    >
                                        Need Help?
                                    </Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}