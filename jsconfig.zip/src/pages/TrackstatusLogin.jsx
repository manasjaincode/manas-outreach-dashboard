// src/pages/TrackStatusLogin.jsx
import React, { useState, useEffect, useCallback } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { coinStack, ruppee } from '../assets/img/img';
import { useLoader } from '../App';
// apiClient is commented out as we're focusing on frontend only
// import apiClient from '../shared/apiClient';
// useAuth is commented out as authentication state will not be managed via API login here
// import { useAuth } from '../Authcontext';
import ReferralBenefitDisplay from '../shared/ReferralBenefitDisplay'; // Reusing for the left visual

const TrackStatusLogin = () => {
    const [ClientCode, setClientCode] = useState('');
    const [message, setMessage] = useState('');
    const [isError, setIsError] = useState(false);
    const navigate = useNavigate();
    // isAuthenticated and isAuthContextLoading are commented out as useAuth is not used
    // const { isAuthenticated, isLoading: isAuthContextLoading } = useAuth();

    const { showLoader, hideLoader, isLoading: isGlobalLoading } = useLoader();

    useEffect(() => {
        sessionStorage.removeItem('currentClientCodeForOtp');
        sessionStorage.removeItem('authToken');
        sessionStorage.removeItem('otpExpirationTime'); // Ensure it's cleared on initial load
        // IMPORTANT: Clear isTrackStatusFlow on mount to ensure a clean state if user navigates back
        sessionStorage.removeItem('isTrackStatusFlow');
        window.scrollTo(0, 0);
    }, []);

    // This useEffect block for redirection based on authentication is commented out
    // because useAuth login is removed in this frontend-only version.
    // If you uncomment useAuth, this logic can be re-enabled.
    /*
    useEffect(() => {
        if (isAuthContextLoading) {
            return;
        }
        // Decide if logged-in users should be redirected from this page
        // if (isAuthenticated) {
        //    navigate('/dashboard', { replace: true });
        // }
    }, [isAuthenticated, navigate, isAuthContextLoading]);
    */

    const handleLogin = useCallback(async (e) => {
        e.preventDefault();
        setMessage('');
        setIsError(false);

        if (!ClientCode) {
            setMessage('Please enter your Client Code.');
            setIsError(true);
            return;
        }

        showLoader();

        // --- Frontend-only Logic: Simulate successful login and redirect ---
        setTimeout(() => {
            hideLoader();
            setMessage('Client code accepted. Redirecting to OTP verification...');
            setIsError(false);

            // Simulate setting session storage for the next step (OTP verification)
            sessionStorage.setItem('currentClientCodeForOtp', ClientCode);
            sessionStorage.setItem('authToken', 'simulated_track_token_xyz'); // Dummy token
            
            // *** IMPORTANT ADDITION: Set the flag for Track Status flow ***
            sessionStorage.setItem('isTrackStatusFlow', 'true'); 

            navigate('/otpverify'); // Navigate to the OTP verification page
        }, 1500); // Simulate 1.5 seconds of loading
        // --- End Frontend-only Logic ---


        /* --- Original API Call (Commented out completely as per request) ---
        try {
            // !!! IMPORTANT: Replace with your ACTUAL API endpoint for Client Code Login for Tracking/Dashboard !!!
            const response = await apiClient.post('/YourActualLoginForTrackingAPIEndpoint', { ClientCode },
                { timeout: 30000 }
            );

            if (response.data.Status === true) {
                if (response.data.Token && response.data.Token.access_token) {
                    setMessage(response.data.message || 'Login successful! Redirecting to OTP verification...'); // Changed message
                    setIsError(false);

                    sessionStorage.setItem('currentClientCodeForOtp', ClientCode);
                    sessionStorage.setItem('authToken', response.data.Token.access_token);

                    const otpValiditySeconds = parseInt(response.data.Token?.expirytime) || 120;
                    const newOtpExpirationTime = Date.now() + (otpValiditySeconds * 1000);
                    sessionStorage.setItem('otpExpirationTime', newOtpExpirationTime.toString());
                    
                    // *** IMPORTANT ADDITION: Set the flag for Track Status flow ***
                    sessionStorage.setItem('isTrackStatusFlow', 'true');

                    setTimeout(() => {
                        hideLoader();
                        navigate('/otpverify');
                    }, 700);
                } else {
                    setMessage('Login successful, but received an incomplete token response. Please try again or contact support.');
                    setIsError(true);
                    hideLoader();
                }
            } else if (response.data.message) {
                setMessage(response.data.message);
                setIsError(true);
                hideLoader();
            } else {
                setMessage('An unknown error occurred during login. Please try again.');
                setIsError(true);
                hideLoader();
            }
        } catch (error) {
            console.error('API Error:', error);

            if (error.response) {
                console.error("API Error Response Data:", error.response.data);
                console.error("API Error Response Status:", error.response.status);
                setMessage(error.response.data.message || `Server responded with status ${error.response.status}. Please try again.`);
            } else if (error.request) {
                setMessage('No response from server. Check your internet connection or try again later.');
            } else {
                setMessage('An error occurred during login. Please try again.');
            }
            setIsError(true);
            hideLoader();
        }
        */
    }, [ClientCode, navigate, showLoader, hideLoader]);

    // If you enable useAuth, uncomment this block
    /*
    if (isAuthContextLoading) {
        return null;
    }
    */

    return (
        <div className="bg-white relative min-h-screen flex items-center justify-center py-4 sm:py-6">
            <div className={`
                transition-all duration-300 ease-in-out w-full
                ${isGlobalLoading ? 'filter blur-sm brightness-75 pointer-events-none' : ''}
            `}>
                <div className="max-w-7xl mx-auto px-4 sm:px-6 pt-4 lg:pt-20">
                    <div className="grid lg:grid-cols-2 gap-3 items-center lg:min-h-[calc(90vh)]">

                        {/* LEFT COLUMN: Now correctly using ReferralBenefitDisplay with custom text */}
                        <ReferralBenefitDisplay
                            imageSrc={ruppee}
                            headingText="Earn ₹300*"
                            paragraphText="when your friend opens an account using your referral link!"
                        />

                        {/* RIGHT COLUMN (Login/Track Status Form) */}
                        <div className="flex justify-center lg:justify-start mt-8 lg:mt-0 px-4 sm:px-6">
                            <div className="bg-white shadow-xl border border-gray-300 rounded-2xl w-full max-w-xl
                                px-2 py-2 mb-0 sm:py-4 sm:px-6">
                                <div className="text-center mb-4 lg:mb-8">
                                    <h2 className="text-xl sm:text-2xl font-medium text-gray-700 mb-2 lg:mb-10">
                                        Login and track your earnings <br></br>
                                        and referral status
                                    </h2>
                                </div>
                                {message && (
                                    <div className={`mb-4 text-center text-sm font-medium ${isError ? 'text-red-600' : 'text-green-600'}`}>
                                        {message}
                                    </div>
                                )}
                                <form onSubmit={handleLogin}>
                                    <div className="mb-4 lg:mb-6">
                                        <label htmlFor="clientCode" className="block text-sm font-semibold text-gray-700 mb-2 lg:mb-3">
                                            Client Code <span className="text-red-500">*</span>
                                        </label>
                                        <input
                                            type="text"
                                            id="clientCode"
                                            value={ClientCode}
                                            onChange={(e) => {
                                                const value = e.target.value.toUpperCase();
                                                if (/^[A-Z0-9]*$/.test(value) && value.length <= 9) {
                                                    setClientCode(value);
                                                }
                                            }}
                                            placeholder="Enter your client code"
                                            className="w-full px-4 py-2 lg:py-3 border border-gray-350 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent text-gray-700 placeholder-gray-600"
                                            required
                                            maxLength={9}
                                            pattern="[A-Z0-9]{2,9}"
                                            title="Client code must be alphanumeric, between 2 and 9 characters, and contain at least two uppercase letters."
                                        />
                                    </div>

                                    <div className="flex justify-center font-semibold text-gray-900 p-4 lg:p-10 mb-0">
                                        <button
                                            type="submit"
                                            className="w-full py-3 rounded-full text-white font-semibold shadow-md transition-all duration-200 hover:shadow-lg
                                                lg:w-28 lg:max-w-xs lg:py-4"
                                            style={{ background: 'linear-gradient(270deg, #34B350 0%, #76D78A 100%)' }}
                                            disabled={isGlobalLoading}
                                        >
                                            Login
                                        </button>
                                    </div>
                                </form>
                                <div className="text-center space-y-2 lg:space-y-3">
                                    <p className="text-sm text-gray-600 font-normal whitespace-nowrap overflow-hidden text-ellipsis">
                                        Not a registered client yet?{' '}
                                        <Link target='_blank' to="https://ekyc.arihantcapital.com/" className="text-green-500 hover:text-green-600 font-semibold">
                                            Create an account
                                        </Link>.
                                    </p>
                                    <p className="text-sm text-gray-600 font-normal mt-2">
                                        <Link to="/login-mobile-number" className="text-green-500 hover:text-green-600 font-semibold">
                                            Login Using Mobile Number.
                                        </Link>
                                    </p>
                                </div>
                                <div className="mt-4 border-t border-gray-200 w-full" />
                                <div className="flex justify-between mt-4 font-medium text-sm">
                                    <Link
                                        target="_blank"
                                        to="/referfriend"
                                        className="text-green-600 hover:underline mt-2"
                                    >
                                        Refer Friends
                                    </Link>
                                    <Link
                                        target="_blank"
                                        to="https://support.arihantcapital.com/support/solutions/33000138462"
                                        className="text-green-600 hover:underline mt-2"
                                    >
                                        Need Help?
                                    </Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default TrackStatusLogin;