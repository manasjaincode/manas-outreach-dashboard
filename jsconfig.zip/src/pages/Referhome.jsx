import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import SharedLayout from '../shared/ArihantsharedUi';
import OtpVerificationModal from './OtpVerificationModal';

const ReferHome = () => {
  const [clientCode, setClientCode] = useState('');
  const [agreedToTerms, setAgreedToTerms] = useState(false);
  const [message, setMessage] = useState('');
  const [isError, setIsError] = useState(false);
  const [isGlobalLoading, setIsGlobalLoading] = useState(false);
  const [showOtpModal, setShowOtpModal] = useState(false);

  const navigate = useNavigate();

  const isClientCodeValid = clientCode.length >= 2 && clientCode.length <= 9 && /^[A-Z0-9]*$/.test(clientCode);
  const isGenerateButtonEnabled = isClientCodeValid && agreedToTerms;
  const isTrackStatusButtonEnabled = isClientCodeValid;

  const handleGenerate = (e) => {
    e.preventDefault();
    setMessage('');
    setIsError(false);

    if (!agreedToTerms) {
      setMessage('Please agree to the Terms & Conditions to generate the link.');
      setIsError(true);
      return;
    }

    if (!isClientCodeValid) {
      setMessage('Invalid client code. Please check your input.');
      setIsError(true);
      return;
    }

    setIsGlobalLoading(true);
    setTimeout(() => {
      setMessage(`Referral link generated for client code: ${clientCode}`);
      setIsError(false);
      setIsGlobalLoading(false);
      navigate('/referfriend', { state: { clientCode } });
    }, 1500);
  };

  const handleOtpVerified = (verifiedClientCode) => {
    setShowOtpModal(false);
    setMessage(`Client code ${verifiedClientCode} verified. Redirecting to Dashboard.`);
    setIsError(false);
    navigate('/dashboard-ts', { state: { clientCode: verifiedClientCode } });
  };

  return (
    <SharedLayout>
      <div className="flex justify-center lg:justify-start w-full px-4 sm:px-6 mt-4 sm:mt-12 lg:mt-16">
        <div
          className="bg-white shadow-xl border border-gray-300 rounded-2xl w-full max-w-md lg:max-w-[568px]
                     p-4 sm:p-8 lg:p-10 flex flex-col items-center gap-3 sm:gap-5"
        >
          <div className="text-center w-full">
            <h2 className="text-xl sm:text-2xl font-medium text-gray-700 mb-4">
              Generate a referral QR & link <br className="lg:hidden" />
              with your client code
            </h2>
          </div>
          {message && (
            <div className={`text-center text-sm font-medium ${isError ? 'text-red-600' : 'text-green-600'} w-full`}>
              {message}
            </div>
          )}
          <form onSubmit={handleGenerate} className="w-full">
            <div className="mb-4 px-0">
              <label htmlFor="clientCode" className="block text-sm font-semibold text-gray-700 mb-3">
                Client Code <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                id="clientCode"
                value={clientCode}
                onChange={(e) => {
                  const value = e.target.value.toUpperCase();
                  if (value === '' || (/^[A-Z0-9]*$/.test(value) && value.length <= 9)) {
                    setClientCode(value);
                  }
                }}
                placeholder="Enter your client code"
                className="w-full px-4 py-2 sm:py-3 border border-gray-350 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent text-gray-700 placeholder-gray-600"
                required
                maxLength={9}
                pattern="[A-Z0-9]{2,9}"
                title="Client code must be alphanumeric, between 2 and 9 characters."
              />
            </div>

            <div className="flex items-center mb-5 px-0">
              <input
                id="agreeToTerms"
                type="checkbox"
                checked={agreedToTerms}
                onChange={(e) => setAgreedToTerms(e.target.checked)}
                className="h-4 w-4 text-green-500 focus:ring-green-500 border-gray-300 rounded"
              />
              <label htmlFor="agreeToTerms" className="ml-2 block text-sm text-gray-900">
                I agree to <Link to="https://refer.arihantcapital.com/Home/TermsandCondition" target="_blank" className="text-green-600 hover:underline">Terms & Condition</Link>
              </label>
            </div>

            <div className="flex flex-col sm:flex-row justify-center w-full gap-4 px-0">
              <button
                type="button"
                onClick={() => {
                  if (isTrackStatusButtonEnabled) {
                    setShowOtpModal(true);
                  } else {
                    setMessage('Please enter a valid client code to track status.');
                    setIsError(true);
                  }
                }}
                className={`flex-1 py-2 sm:py-3 rounded-full text-green-600 font-semibold shadow-md transition-all duration-200 hover:shadow-lg lg:py-4 flex items-center justify-center
                          ${!isTrackStatusButtonEnabled ? 'opacity-50 cursor-not-allowed' : ''}`}
                style={{ borderRadius: '100px', border: '1px solid #34B350', background: '#FFF' }}
                disabled={!isTrackStatusButtonEnabled}
              >
                Track Status
              </button>
              <button
                type="submit"
                className={`flex-1 py-2 sm:py-3 rounded-full text-white font-semibold shadow-md transition-all duration-200 hover:shadow-lg lg:py-4
                          ${!isGenerateButtonEnabled || isGlobalLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
                style={{ background: 'linear-gradient(270deg, #34B350 0%, #76D78A 100%)' }}
                disabled={!isGenerateButtonEnabled || isGlobalLoading}
              >
                {isGlobalLoading ? 'Generating...' : 'Generate'}
              </button>
            </div>
          </form>
          <div className="text-center space-y-1 w-full mt-4">
            <p className="text-sm text-gray-600 font-normal">
              Not a registered client yet?{' '}
              <Link target='_blank' to="https://ekyc.arihantcapital.com/" className="text-green-500 hover:text-green-600 font-semibold">
                Create an account
              </Link>.
            </p>
          </div>
          <div className="mt-2 border-t border-gray-200 w-full" />
          <div className="flex justify-center items-center w-full">
            <Link
              target="_blank"
              to="https://support.arihantcapital.com/support/solutions/33000138462"
              className="text-xs font-medium hover:underline block py-1"
              style={{ color: 'rgba(52, 179, 80, 1)' }}
            >
              Need Help?
            </Link>
          </div>
        </div>
      </div>

      <OtpVerificationModal
        isOpen={showOtpModal}
        onClose={() => setShowOtpModal(false)}
        onVerify={handleOtpVerified}
        clientCode={clientCode}
      />
    </SharedLayout>
  );
};

export default ReferHome;