import React, { useState, useMemo, useEffect } from 'react';
import { ChevronDown, HelpCircle, Info, Search, X } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom'; // Import useLocation to get state

// Import your images (adjust paths as per your project structure)
// Example: If your images are in 'src/assets/img/icon/', and TrackStatusPage.jsx is in 'src/pages/',
// then the paths might be '../../assets/img/icon/totalearning.png'
import totalEarningsIcon from '../assets/img/icon/totalearning.png';
import paymentReceivedIcon from '../assets/img/icon/payment received.png';

// Import the ReferralContent component (adjust path if needed)
// Assuming ReferralContent is a separate component for the "Refer Friends" tab content
import ReferralContent from '../shared/ReferralContent';

// You might want to import a SharedLayout if this page is also wrapped in one
// import SharedLayout from '../shared/ArihantsharedUi'; // Uncomment and adjust path if you use a layout

const DashboardTS = () => {
    const navigate = useNavigate();
    const location = useLocation(); // Hook to access state passed via navigate

    // State to hold the clientCode passed from ReferHome
    const [clientCodeFromReferral, setClientCodeFromReferral] = useState('');

    useEffect(() => {
        // Retrieve clientCode from location.state when the component mounts
        if (location.state && location.state.clientCode) {
            setClientCodeFromReferral(location.state.clientCode);
            // Optionally, you could use this clientCode to fetch actual data
            console.log("Client Code received in TrackStatusPage:", location.state.clientCode);
        }
    }, [location.state]);


    const [selectedYear, setSelectedYear] = useState('2025');
    const [selectedMonth, setSelectedMonth] = useState('July');
    const [activeTab, setActiveTab] = useState('referFriends'); // Default to referFriends
    const [earningsSubChip, setEarningsSubChip] = useState('pending');
    const [searchTerm, setSearchTerm] = useState('');

    // States for modals related to Earnings tab
    const [showTotalEarningsModal, setShowTotalEarningsModal] = useState(false);
    const [showPaymentReceivedModal, setShowPaymentReceivedModal] = useState(false);

    // Dummy data for referrals (replace with actual API data in a real app)
    const activeReferrals = [
        { name: 'Advait Mujumdar', initials: 'AM', contact: '9876543210', status: 'Active' },
        { name: 'Anand Tiwari', initials: 'AT', contact: '9876543210', status: 'Active' },
        { name: 'Charal Pandey', initials: 'CP', contact: '9876543210', status: 'Active' },
        { name: 'Prathmesh Verma', initials: 'PV', contact: '9876543210', status: 'Active' },
        { name: 'Rohit Sharma', initials: 'RS', contact: '9876543210', status: 'Active' },
        { name: 'Priya Singh', initials: 'PS', contact: '9876543210', status: 'Active' },
        { name: 'Rahul Gupta', initials: 'RG', contact: '9876543211', status: 'Active' },
        { name: 'Sneha Sharma', initials: 'SS', contact: '9876543212', status: 'Active' },
        { name: 'Vikram Patel', initials: 'VP', contact: '9876543213', status: 'Active' },
        { name: 'Kavita Devi', initials: 'KD', contact: '9876543214', status: 'Active' },
    ];

    const pendingKYC = [
        { name: 'Manas Jain', initials: 'MJ', contact: '9876543210', status: 'Pending' },
        { name: 'Anand Tiwari', initials: 'AT', contact: '9876543210', status: 'Pending' },
        { name: 'Charal Pandey', initials: 'CP', contact: '9876543210', status: 'Pending' },
        { name: 'Prathmesh Verma', initials: 'PV', contact: '9876543210', status: 'Pending' },
        { name: 'Ravi Kumar', initials: 'RK', contact: '9876543210', status: 'Pending' },
        { name: 'Sneha Patel', initials: 'SP', contact: '9876543210', status: 'Pending' },
        { name: 'Amit Gupta', initials: 'AG', contact: '9876543210', status: 'Pending' },
        { name: 'Neha Joshi', initials: 'NJ', contact: '9876543210', status: 'Pending' },
        { name: 'Vikram Singh', initials: 'VS', contact: '9876543210', status: 'Pending' },
        { name: 'Kavya Rao', initials: 'KR', contact: '9876543210', status: 'Pending' },
        { name: 'Deepak Verma', initials: 'DV', contact: '9876543210', status: 'Pending' },
        { name: 'Sonia Malhotra', initials: 'SM', contact: '9876543210', status: 'Pending' },
        { name: 'Arjun Reddy', initials: 'AR', contact: '9876543215', status: 'Pending' },
        { name: 'Pooja Singh', initials: 'PS', contact: '9876543216', status: 'Pending' },
    ];

    // Memoize allReferrals based on the active sub-chip
    const allReferrals = useMemo(() => (earningsSubChip === 'active' ? activeReferrals : pendingKYC), [earningsSubChip]);

    // Memoize filteredReferrals based on search term and allReferrals data
    const filteredReferrals = useMemo(() => {
        if (!searchTerm) {
            return allReferrals;
        }
        const lowerCaseSearchTerm = searchTerm.toLowerCase();
        return allReferrals.filter(
            (referral) =>
                referral.name.toLowerCase().startsWith(lowerCaseSearchTerm) ||
                referral.contact.startsWith(lowerCaseSearchTerm)
        );
    }, [allReferrals, searchTerm]);

    // Function to get a random background color for initials (for avatars)
    const getInitialsBackground = (initials) => {
        const colors = ['bg-green-100', 'bg-blue-100', 'bg-purple-100', 'bg-pink-100', 'bg-yellow-100', 'bg-indigo-100'];
        const hash = initials.charCodeAt(0) + initials.charCodeAt(1);
        return colors[(hash % colors.length)];
    };

    return (
        // Wrap the content with SharedLayout if you have one, otherwise keep this div
        // <SharedLayout>
            <div className="min-h-screen bg-white font-futura py-20">
                <div className="max-w-7xl mx-auto px-4 sm:px-6">
                    <div className="bg-white rounded-lg shadow-md mt-8 p-8 sm:p-10 border border-gray-200">
                        {/* Display the clientCode if it was passed */}
                      

                        {/* Combined Header and Tabs Section */}
                        <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4 mb-6 border-b border-gray-200 pb-2">
                            <div className="flex space-x-4">
                                <button
                                    onClick={() => { setActiveTab('referFriends'); }}
                                    className={`px-4 py-2 text-base font-medium transition-colors duration-200 ${
                                        activeTab === 'referFriends'
                                            ? 'text-green-700 border-b-2 border-green-700'
                                            : 'text-gray-600 hover:text-green-700'
                                    }`}
                                >
                                    Refer Friends
                                </button>
                                <button
                                    onClick={() => setActiveTab('earnings')}
                                    className={`px-4 py-2 text-base font-medium transition-colors duration-200 ${
                                        activeTab === 'earnings'
                                            ? 'text-green-700 border-b-2 border-green-700'
                                            : 'text-gray-600 hover:text-green-700'
                                    }`}
                                >
                                    Earnings
                                </button>
                            </div>

                            {/* Date Dropdowns and Need Help button - Conditionally rendered */}
                            {activeTab === 'earnings' && (
                                <div className="flex flex-wrap gap-3 items-center justify-center md:justify-end">
                                    <div className="relative w-32">
                                        <select
                                            value={selectedYear}
                                            onChange={(e) => setSelectedYear(e.target.value)}
                                            className="appearance-none bg-white border border-gray-300 rounded-lg px-3 py-2 pr-8 text-gray-700 w-full focus:ring-2 focus:ring-green-500 focus:outline-none focus:border-transparent transition-all duration-200"
                                        >
                                            <option>2024</option>
                                            <option>2025</option>
                                            <option>2023</option>
                                            <option>2022</option>
                                        </select>
                                        <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
                                    </div>

                                    <div className="relative w-32">
                                        <select
                                            value={selectedMonth}
                                            onChange={(e) => setSelectedMonth(e.target.value)}
                                            className="appearance-none bg-white border border-gray-300 rounded-lg px-3 py-2 pr-8 text-gray-700 w-full focus:ring-2 focus:ring-green-500 focus:outline-none focus:border-transparent transition-all duration-200"
                                        >
                                            <option>May</option>
                                            <option>June</option>
                                            <option>July</option>
                                            <option>April</option>
                                            <option>March</option>
                                            <option>February</option>
                                            <option>January</option>
                                        </select>
                                        <ChevronDown className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400 pointer-events-none" />
                                    </div>

                                    <button className="flex items-center gap-1 text-sm sm:text-base border border-green-500 text-green-600 px-4 py-2 rounded-full hover:bg-green-50 transition-colors duration-200 shadow-sm">
                                        <HelpCircle className="w-4 h-4" />
                                        <span>Need Help</span>
                                    </button>
                                </div>
                            )}

                            {activeTab === 'referFriends' && (
                                <div className="flex flex-wrap gap-3 items-center justify-center md:justify-end">
                                    <button className="flex items-center gap-1 text-sm sm:text-base border border-green-500 text-green-600 px-4 py-2 rounded-full hover:bg-green-50 transition-colors duration-200 shadow-sm">
                                        <HelpCircle className="w-4 h-4" />
                                        <span>Need Help</span>
                                    </button>
                                </div>
                            )}
                        </div>

                        {/* Refer Friends Tab Content */}
                        {activeTab === 'referFriends' && (
                            // Ensure ReferralContent is the correct component for this section
                            <ReferralContent showHeader={false} isNested={true} />
                        )}

                        {/* Earnings Tab Content */}
                        {activeTab === 'earnings' && (
                            <div className="mt-6">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                                    {/* Total Earnings Box */}
                                    <div className="bg-[#faf1ff] px-4 py-3 rounded-lg border border-purple-100 shadow-sm flex flex-col gap-2 justify-between">
                                        <div className="flex items-center justify-between">
                                            <div className="flex items-center">
                                                <h3 className="text-base font-normal text-gray-600">Total Earnings</h3>
                                                <Info
                                                    className="w-4 h-4 text-gray-400 ml-2 cursor-pointer"
                                                    onClick={() => setShowTotalEarningsModal(true)}
                                                />
                                            </div>
                                            <img src={totalEarningsIcon} alt="Total Earnings Icon" className="w-10 h-10 object-contain" />
                                        </div>
                                        <p className="text-xl font-bold text-gray-900">₹ 0</p>
                                    </div>

                                    {/* Payment Received Box */}
                                    <div className="bg-[#f0f5ff] px-4 py-3 rounded-lg border border-blue-100 shadow-sm flex flex-col gap-2 justify-between">
                                        <div className="flex items-center justify-between">
                                            <div className="flex items-center">
                                                <h3 className="text-base font-normal text-gray-600">Payment Received</h3>
                                                <Info
                                                    className="w-4 h-4 text-gray-400 ml-2 cursor-pointer"
                                                    onClick={() => setShowPaymentReceivedModal(true)}
                                                />
                                            </div>
                                            <img src={paymentReceivedIcon} alt="Payment Received Icon" className="w-10 h-10 object-contain" />
                                        </div>
                                        <p className="text-xl font-bold text-gray-900">₹ 0</p>
                                    </div>
                                </div>


                                {/* Sub-tabs for Earnings (Active Referrals / Pending KYC) */}
                                <div className="flex flex-wrap gap-3 mb-4 border-b border-gray-200 pb-2">
                                    <button
                                        onClick={() => { setEarningsSubChip('active'); setSearchTerm(''); }}
                                        className={`px-4 py-2 rounded-full text-sm font-medium border transition-colors duration-200 whitespace-nowrap shadow-sm ${
                                            earningsSubChip === 'active'
                                                ? 'bg-green-100 text-green-700 border-green-200'
                                                : 'bg-gray-100 text-gray-600 border-gray-200 hover:bg-gray-200'
                                        }`}
                                    >
                                        Active Referrals ({activeReferrals.length})
                                    </button>
                                    <button
                                        onClick={() => { setEarningsSubChip('pending'); setSearchTerm(''); }}
                                        className={`px-4 py-2 rounded-full text-sm font-medium border transition-colors duration-200 whitespace-nowrap shadow-sm ${
                                            earningsSubChip === 'pending'
                                                ? 'bg-green-100 text-green-700 border-green-200'
                                                : 'bg-gray-100 text-gray-600 border-gray-200 hover:bg-gray-200'
                                        }`}
                                    >
                                        Pending KYC ({pendingKYC.length})
                                    </button>
                                </div>

                                {/* Find/Search Input */}
                                <div className="relative mb-6 w-full max-w-sm">
                                    <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                                    <input
                                        type="text"
                                        placeholder="Find by name or number..."
                                        className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-green-500 focus:border-green-500 text-sm text-gray-700"
                                        value={searchTerm}
                                        onChange={(e) => setSearchTerm(e.target.value)}
                                    />
                                </div>

                                {/* Earnings Table / No Referrals Message */}
                                {filteredReferrals.length > 0 ? (
                                    <div className="bg-white rounded-lg shadow-sm border border-gray-200">
                                        <div className="overflow-y-auto max-h-[220px]">
                                            <table className="w-full table-auto">
                                                <thead className="border-b bg-gray-50 sticky top-0 z-10">
                                                    <tr>
                                                        <th className="text-left py-3 px-3 sm:px-6 text-sm font-medium text-gray-600">
                                                            Name
                                                        </th>
                                                        <th className="text-left py-3 px-3 sm:px-6 text-sm font-medium text-gray-600">
                                                            Contact number
                                                        </th>
                                                        <th className="text-left py-3 px-3 sm:px-6 text-sm font-medium text-gray-600">
                                                            Status
                                                        </th>
                                                        {earningsSubChip === 'pending' && (
                                                            <th className="text-left py-3 px-3 sm:px-6 text-sm font-medium text-gray-600">
                                                                Action
                                                            </th>
                                                        )}
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {filteredReferrals.map((item, idx) => (
                                                        <tr key={idx} className="border-b border-gray-100 hover:bg-gray-50 transition-colors duration-150">
                                                            <td className="py-3 px-3 sm:px-6">
                                                                <div className="flex items-center space-x-3 whitespace-nowrap">
                                                                    <div
                                                                        className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold text-gray-700 shrink-0 ${getInitialsBackground(item.initials)}`}
                                                                    >
                                                                        {item.initials}
                                                                    </div>
                                                                    <span className="text-gray-900 font-medium">{item.name}</span>
                                                                </div>
                                                            </td>
                                                            <td className="py-3 px-3 sm:px-6 text-gray-600 whitespace-nowrap">{item.contact}</td>
                                                            <td className="py-3 px-3 sm:px-6">
                                                                <span
                                                                    className={`inline-flex px-2 py-1 rounded-full text-xs font-medium ${
                                                                        item.status === 'Active' ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700'
                                                                    } whitespace-nowrap`}
                                                                >
                                                                    {item.status}
                                                                </span>
                                                            </td>
                                                            {earningsSubChip === 'pending' && (
                                                                <td className="py-3 px-3 sm:px-6">
                                                                    <button className="text-green-600 border border-green-600 px-3 py-1 rounded-full text-sm hover:bg-green-50 transition-colors duration-200 shadow-sm whitespace-nowrap">
                                                                        Remind
                                                                    </button>
                                                                </td>
                                                            )}
                                                        </tr>
                                                    ))}
                                                </tbody>
                                            </table>
                                            {filteredReferrals.length === 0 && (
                                                <div className="text-center py-4 text-gray-500">No matching referrals found.</div>
                                            )}
                                        </div>
                                    </div>
                                ) : (
                                    <div className="text-center py-12 bg-white rounded-lg px-4 sm:px-6 shadow-sm border border-gray-200">
                                        <div className="mb-4">
                                            <h3 className="text-lg font-semibold text-gray-900 mb-1">
                                                No active referrals yet
                                            </h3>
                                            <p className="text-gray-600 text-sm max-w-sm mx-auto">
                                                Invite your friends to ArihantPlus and start earning right away
                                            </p>
                                        </div>
                                        <button
                                            onClick={() => setActiveTab('referFriends')}
                                            className="bg-green-500 hover:bg-green-600 text-white px-8 py-3 rounded-full font-medium transition-colors duration-200 shadow-md hover:shadow-lg whitespace-nowrap"
                                        >
                                            Refer a Friend
                                        </button>
                                    </div>
                                )}
                            </div>
                        )}
                    </div>
                </div>

                {/* Total Earnings Modal */}
                {showTotalEarningsModal && (
                    <div className="fixed inset-0 bg-black/20 flex items-center justify-center p-4 z-50">
                        <div className="bg-white rounded-lg shadow-xl w-full max-w-md mx-auto p-6 relative">
                            <button
                                onClick={() => setShowTotalEarningsModal(false)}
                                className="absolute top-3 right-3 text-gray-400 hover:text-gray-600 transition-colors"
                            >
                                <X className="w-5 h-5" />
                            </button>
                            <h3 className="text-lg font-semibold text-gray-900 mb-4">Total Earnings</h3>
                            <p className="text-gray-700 text-sm">
                                Your total earnings refers to a sum of all the earnings you have received through referrals. This includes both the confirmed and pending earnings you make from all your successful referral activities. For more specific information about your earnings, please visit the "Total Earnings" section in your account.
                            </p>
                        </div>
                    </div>
                )}

                {/* Payment Received Modal */}
                {showPaymentReceivedModal && (
                    <div className="fixed inset-0 bg-black/20 flex items-center justify-center p-4 z-50">
                        <div className="bg-white rounded-lg shadow-xl w-full max-w-md mx-auto p-6 relative">
                            <button
                                onClick={() => setShowPaymentReceivedModal(false)}
                                className="absolute top-3 right-3 text-gray-400 hover:text-gray-600 transition-colors"
                            >
                                <X className="w-5 h-5" />
                            </button>
                            <h3 className="text-lg font-semibold text-gray-900 mb-4">Payout Received</h3>
                            <p className="text-gray-700 text-sm">
                                The "Payment Received" section displays all the payments successfully credited to your account from the referral activities. This includes processed and cleared payments. Regarding specific details of each payment, visit the "Payment History" section of your account.
                            </p>
                        </div>
                    </div>
                )}
            </div>
        // </SharedLayout>
    );
};

export default DashboardTS;