// import { useEffect, useState } from "react";
// import axios from "axios";

// const ReferredFriendsPage = ({ onAddMoreClick }) => {
//   const [referrals, setReferrals] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [pageNumber, setPageNumber] = useState(0);
//   const [pageSize] = useState(50);
//   const [searchType, setSearchType] = useState("MOBILENO");
//   const [searchValue, setSearchValue] = useState("");
//   const [dateFrom, setDateFrom] = useState("");
//   const [dateTo, setDateTo] = useState("");
//   const [totalRecords, setTotalRecords] = useState(0);

//   useEffect(() => {
//     fetchReferralData();
//   }, [pageNumber, pageSize]);

//   // This function is for formatting dates sent to the API
//   const formatDate = (input) => {
//     if (!input) return "";
//     const [yyyy, mm, dd] = input.split("-");
//     return `${dd}-${mm}-${yyyy}`;
//   };

//   // This new function is for formatting dates for display in the table (only date part)
//   const formatDisplayDate = (dateTimeString) => {
//     if (!dateTimeString) return "";
//     try {
//       const date = new Date(dateTimeString);
//       const day = String(date.getDate()).padStart(2, '0');
//       const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are 0-indexed
//       const year = date.getFullYear();
//       return `${day}-${month}-${year}`;
//     } catch (e) {
//       console.error("Error parsing date for display:", dateTimeString, e);
//       return dateTimeString; // Fallback to original string if parsing fails
//     }
//   };

//   const fetchReferralData = async () => {
//     setLoading(true);
//     try {
//       const params = new URLSearchParams();

//       params.append('pageNumber', pageNumber);
//       params.append('size', pageSize);

//       if (searchType && searchValue) {
//         params.append('SearchType', searchType);
//         params.append('Search', searchValue);
//       }

//       if (dateFrom) params.append('datefrm', formatDate(dateFrom));
//       if (dateTo) params.append('dateto', formatDate(dateTo));

//       const res = await axios.post(
//         `https://uatreferpartner.arihantcapital.com/api/v1/ReferralPartner/Report/MyReferralleads?${params.toString()}`,
//         {},
//         {
//           headers: {
//             'Authorization': `Bearer ${sessionStorage.getItem('authToken')}`,
//             "Content-Type": "application/json"
//           }
//         }
//       );

//       if (res.data.success) {
//         setReferrals(res.data.result.ReferPartner || []);
//         setTotalRecords(res.data.result.TotalCount || 0);
//       } else {
//         setReferrals([]);
//         setTotalRecords(0);
//       }
//     } catch (error) {
//       console.error("Error fetching referrals:", error);
//       setReferrals([]);
//       setTotalRecords(0);
//     } finally {
//       setLoading(false);
//     }
//   };

//   const isNextButtonDisabled = loading || (pageNumber + 1) * pageSize >= totalRecords;
//   const isPreviousButtonDisabled = loading || pageNumber === 0;


//   return (
//     <div className="mt-6 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
//       <div className="flex justify-end mb-6">
//         <button
//           onClick={onAddMoreClick}
//           className="bg-green-500 hover:bg-green-600 text-white px-8 py-3 rounded-full font-medium transition duration-200 shadow-md"
//         >
//           Add More
//         </button>
//       </div>

//       {!loading && referrals.length > 0 ? (
//         <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
//           <div className="overflow-x-auto">
//             <table className="w-full min-w-[600px] table-auto">
//               <thead className="bg-gray-50 border-b">
//                 <tr>
//                   <th className="text-left py-3 px-6 text-sm font-medium text-gray-600">Name</th>
//                   <th className="text-left py-3 px-6 text-sm font-medium text-gray-600">Contact Number</th>
//                   <th className="text-left py-3 px-6 text-sm font-medium text-gray-600">Status</th>
//                   <th className="text-left py-3 px-6 text-sm font-medium text-gray-600">Referral Date</th>
//                   <th className="text-left py-3 px-6 text-sm font-medium text-gray-600">Remark</th>
//                 </tr>
//               </thead>
//               <tbody>
//                 {referrals.map((ref) => (
//                   <tr key={ref.RefId} className="border-t">
//                     <td className="py-3 px-6 text-sm text-gray-800">{ref.ReferralName}</td>
//                     <td className="py-3 px-6 text-sm text-gray-800">{ref.RefrerralMobile}</td>
//                     <td className="py-3 px-6 text-sm text-gray-800">{ref.Status}</td>
//                     <td className="py-3 px-6 text-sm text-gray-800">{formatDisplayDate(ref.CreatedOn)}</td> {/* Modified here */}
//                     <td className="py-3 px-6 text-sm text-gray-800">{ref.Remark}</td>
//                   </tr>
//                 ))}
//               </tbody>
//             </table>
//           </div>
//         </div>
//       ) : (
//         !loading && (
//           <div className="text-center py-12 bg-white rounded-lg px-4 shadow-sm border border-gray-200">
//             <h3 className="text-lg font-semibold text-gray-900 mb-1">No referrals yet</h3>
//             <p className="text-gray-600 text-sm max-w-sm mx-auto mb-4">
//               Invite your friends to ArihantPlus and start earning right away
//             </p>
//             <button
//               onClick={onAddMoreClick}
//               className="bg-[#34ab50] hover:bg-[#2c9146] text-white px-8 py-3 rounded-full font-medium transition shadow-md"
//             >
//               Refer a Friend
//             </button>
//           </div>
//         )
//       )}

//       {!loading && referrals.length > 0 && (
//         <div className="flex justify-between items-center mt-6">
//           <button
//             onClick={() => setPageNumber((prev) => Math.max(prev - 1, 0))}
//             disabled={isPreviousButtonDisabled}
//             className={`px-4 py-2 border rounded ${isPreviousButtonDisabled ? "opacity-50 text-black cursor-not-allowed" : ""}`}
//           >
//             Previous
//           </button>
//           <span className="text-sm text-gray-700">Page {pageNumber + 1}</span>
//           <button
//             onClick={() => setPageNumber((prev) => prev + 1)}
//             disabled={isNextButtonDisabled}
//             className={`px-4 py-2 border rounded ${isNextButtonDisabled ? "opacity-50 text-black cursor-not-allowed" : ""}`}
//           >
//             Next
//           </button>
//         </div>
//       )}
//     </div>
//   );
// };

// export default ReferredFriendsPage;