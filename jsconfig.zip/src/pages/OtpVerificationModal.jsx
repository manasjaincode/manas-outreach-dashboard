import React, { useState, useEffect } from 'react';
// Assuming Generatelink.jsx is in a place where it can be imported.
// Adjust the path accordingly based on your file structure.
// If 'referfriend' is imported from Generatelink.jsx, ensure it's a named export.
// Example: import { referfriend } from './Generatelink';
// For this example, I'll assume 'referfriend' is globally available or imported elsewhere.
// If 'Generatelink.jsx' contains a default export function, you might do:
// import referfriend from './Generatelink';
// For now, I'll comment out the import for 'referfriend' as it's not defined in the provided snippet.

const OtpVerificationModal = ({ isOpen, onClose, onVerify, clientCode }) => {
  const [otp, setOtp] = useState('');
  const [message, setMessage] = useState('');
  const [isError, setIsError] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Timer states
  const [timer, setTimer] = useState(120); // 2 minutes in seconds
  const [canResend, setCanResend] = useState(false);

  // Reset state when the modal opens
  useEffect(() => {
    if (isOpen) {
      setOtp('');
      setMessage('');
      setIsError(false);
      setIsLoading(false);
      setTimer(120); // Reset timer to 2 minutes
      setCanResend(false); // Cannot resend initially
    }
  }, [isOpen]);

  // Timer logic
  useEffect(() => {
    let interval;
    if (isOpen && timer > 0) {
      interval = setInterval(() => {
        setTimer((prevTimer) => prevTimer - 1);
      }, 1000);
    } else if (timer === 0) {
      setCanResend(true); // Allow resend when timer reaches 0
      clearInterval(interval); // Clear interval when timer runs out
    }
    return () => clearInterval(interval); // Cleanup on component unmount or if modal closes
  }, [isOpen, timer]);

  // Format the timer display
  const formatTime = (seconds) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes.toString().padStart(2, '0')}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  // If the modal is not open, render nothing
  if (!isOpen) {
    return null;
  }

  // Handle OTP input changes, allowing only digits and limiting length
  const handleOtpChange = (e) => {
    const value = e.target.value.replace(/\D/g, ''); // Remove non-digits
    if (value.length <= 6) { // Limit to 6 characters (common OTP length)
      setOtp(value);
    }
  };

  // Handle the OTP verification submission
  const handleVerifyOtp = async (e) => {
    e.preventDefault(); // Prevent default form submission behavior
    setMessage(''); // Clear previous messages
    setIsError(false); // Reset error state

    // Basic validation: ensure OTP is 6 digits long
    if (otp.length !== 6) {
      setMessage('Please enter a 6-digit OTP.');
      setIsError(true);
      return;
    }

    setIsLoading(true); // Set loading state to true during verification
    // Simulate an API call for OTP verification
    setTimeout(() => {
      setIsLoading(false); // End loading state

      // In a real application, you would send `clientCode` and `otp` to your backend
      // and handle the actual API response here.
      if (otp === '123456') { // Example: Hardcoded success OTP for demonstration purposes
        setMessage('OTP verified successfully!');
        setIsError(false);
        onVerify(clientCode); // Call the parent component's verification handler
        onClose(); // Close the modal on successful verification
      } else {
        setMessage('Invalid OTP. Please try again.');
        setIsError(true);
      }
    }, 1500); // Simulate network delay
  };

  const handleResendOtp = () => {
    // Simulate resending OTP action
    setMessage('Resending OTP...');
    setIsError(false);
    setCanResend(false); // Disable resend button immediately
    setTimer(120); // Reset timer for new OTP

    setTimeout(() => {
      setMessage('OTP resent successfully!');
      // In a real app, you'd make an API call to resend OTP
    }, 1000);
  };

  // Handle "Need Help?" click
  const handleNeedHelpClick = () => {
    window.open('https://support.arihantcapital.com/support/solutions/33000138462', '_blank');
  };

  // Handle "Refer a Friend" click - CALLING THE FUNCTION FROM GENERATELINK.JSX
  const handleReferFriendClick = () => {
    // You would pass any necessary arguments to this function, e.g., the current clientCode
    // referfriend(clientCode); // <--- CALLING THE IMPORTED FUNCTION (Uncomment if referfriend is imported)
    onClose(); // Optionally close the OTP modal after triggering the referral action
  };

  return (
    // Modal Overlay: Fixed position, covers the whole screen, dark semi-transparent background
    <div className="fixed inset-0 bg-black/40 bg-opacity-50 flex items-center justify-center z-50 p-4 sm:p-6">

      {/* Modal Content Box: White background, rounded corners, shadow, responsive sizing */}
      <div
        className="bg-white shadow-2xl border border-gray-300 rounded-2xl w-full max-w-md
                  p-8 flex flex-col items-center gap-5 relative transform transition-all duration-300 scale-100"
      >
        {/* Close Button */}
        <button
          onClick={onClose} // Calls the onClose prop from the parent component
          className="absolute top-4 right-4 text-gray-500 hover:text-gray-700 focus:outline-none"
          aria-label="Close" // Accessibility label
        >
          {/* SVG icon for close (X) */}
          <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        {/* Modal Title and Description */}
        <div className="text-center w-full">
          <h2 className="text-xl sm:text-2xl font-medium text-gray-700 mb-2">
            Verify Your Client Code
          </h2>
          <p className="text-gray-600 text-sm mb-4">
            An OTP has been sent to your registered mobile number for client code: <span className="font-semibold">{clientCode}</span>
          </p>
        </div>

        {/* Message Display (success/error) */}
        {message && (
          <div className={`text-center text-sm font-medium ${isError ? 'text-red-600' : 'text-green-600'} w-full`}>
            {message}
          </div>
        )}

        {/* OTP Input Form */}
        <form onSubmit={handleVerifyOtp} className="w-full">
          <div className="mb-6 px-4">
            <label htmlFor="otp" className="block text-sm font-semibold text-gray-700 mb-3">
              Enter OTP <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              id="otp"
              value={otp}
              onChange={handleOtpChange}
              placeholder="Enter 6-digit OTP"
              className="w-full px-4 py-3 border border-gray-350 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent text-gray-700 placeholder-gray-600 text-center tracking-widest"
              inputMode="numeric" // Optimizes for numeric keyboard on mobile
              pattern="\d{6}" // HTML5 pattern for 6 digits
              maxLength={6}
              required
            />
          </div>

          {/* Verify OTP Button */}
          <div className="flex justify-center w-full px-4">
            <button
              type="submit"
              className={`w-full py-3 rounded-full text-white font-semibold shadow-md transition-all duration-200 hover:shadow-lg lg:py-4
                ${isLoading || otp.length !== 6 ? 'opacity-50 cursor-not-allowed' : ''}`}
              style={{ background: 'linear-gradient(270deg, #34B350 0%, #76D78A 100%)' }}
              disabled={isLoading || otp.length !== 6} // Disable button when loading or OTP is not 6 digits
            >
              {isLoading ? 'Verifying...' : 'Verify OTP'}
            </button>
          </div>
        </form>

        {/* Resend OTP and Timer */}
        <div className="text-center mt-4">
          {timer > 0 ? (
            <p className="text-gray-600 text-sm">Did not receive the OTP? Resend OTP in <span className="font-semibold text-green-600">{formatTime(timer)}</span></p>
          ) : (
            <button
              onClick={handleResendOtp}
              className={`text-sm text-green-600 hover:underline focus:outline-none ${!canResend ? 'opacity-50 cursor-not-allowed' : ''}`}
              disabled={!canResend || isLoading} // Disable if not allowed to resend or still loading verification
            >
              Resend OTP
            </button>
          )}
        </div>

        {/* Thin black line separator */}
        <div className="w-full border-t border-gray-300 my-6"></div>

        {/* Need Help? | Refer a Friend section */}
        <div className="flex justify-center items-center text-sm">
          <button
            onClick={handleNeedHelpClick}
            className="text-green-600 hover:underline font-medium focus:outline-none"
          >
            Need Help?
          </button>
          <span className="text-gray-400 mx-3">|</span>
          <button
            onClick={handleReferFriendClick} // Now calls the function from Generatelink.jsx
            className="text-green-600 hover:underline font-medium focus:outline-none"
          >
            Refer a Friend
          </button>
        </div>
      </div>
    </div>
  );
};

export default OtpVerificationModal;
