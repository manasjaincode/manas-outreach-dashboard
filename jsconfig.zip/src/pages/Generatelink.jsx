import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Share2, Copy, X } from 'lucide-react';

import SharedLayout from '../shared/ArihantsharedUi'; // Adjust path if needed

// Import your assets
import acml from "../assets/img/acml.png"; // Placeholder for your QR image
import whatsappIcon from '../assets/img/icon/whatsapp.png';
import facebookIcon from '../assets/img/icon/fb.png';
import gmailIcon from '../assets/img/icon/email.png';
import linkdinIcon from '../assets/img/icon/linkdin.png';
import instagramIcon from '../assets/img/icon/instagram.png';
import twitterIcon from '../assets/img/icon/x.png';
import telegramIcon from '../assets/img/icon/telegram.png';
import messagesIcon from '../assets/img/icon/freechat.png';
import Coinbg from '../assets/img/Coinbg.png'; // Placeholder for your coin background image


const ReferFriend = () => {
    // State from your ReferralContent component
    const [referralCode, setReferralCode] = useState('MMVYC328'); // Replace with actual dynamic code if available
    const [referralLink, setReferralLink] = useState('https://acml.link.example/loginusingmyreferrallink'); // Replace with actual dynamic link
    const [copiedReferralCode, setCopiedReferralCode] = useState(false);
    const [showShareModal, setShowShareModal] = useState(false);

    const handleCopyReferralCode = () => {
        navigator.clipboard.writeText(referralCode).then(() => {
            setCopiedReferralCode(true);
            setTimeout(() => setCopiedReferralCode(false), 2000);
        });
    };

    const handleCopyReferralLink = () => {
        navigator.clipboard.writeText(referralLink).then(() => {
            console.log('Referral link copied!');
        });
    };

    // Social platforms from your ReferralContent component
    const socialPlatforms = [
        { name: 'WhatsApp', icon: whatsappIcon, action: () => { window.open(`https://wa.me/?text=${encodeURIComponent(referralLink)}`, '_blank'); } },
        { name: 'Facebook', icon: facebookIcon, action: () => { window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(referralLink)}`, '_blank'); } },
        { name: 'Gmail', icon: gmailIcon, action: () => { window.open(`mailto:?subject=Check out Arihant Capital!&body=Here's my referral link: ${encodeURIComponent(referralLink)}`, '_blank'); } },
        { name: 'LinkedIn', icon: linkdinIcon, action: () => { window.open(`https://www.linkedin.com/shareArticle?mini=true&url=${encodeURIComponent(referralLink)}&title=Join%20Arihant%20Capital&summary=Open%20an%20account%20with%20my%20referral%20link!`, '_blank'); } },
        { name: 'Instagram', icon: instagramIcon, action: () => alert('Instagram sharing usually requires a direct share from the app or specific API integration.') },
        { name: 'Twitter', icon: twitterIcon, action: () => { window.open(`https://twitter.com/intent/tweet?url=${encodeURIComponent(referralLink)}&text=Open%20an%20account%20with%20Arihant%20Capital%20using%20my%20referral%20link!`, '_blank'); } },
        { name: 'Telegram', icon: telegramIcon, action: () => { window.open(`https://t.me/share/url?url=${encodeURIComponent(referralLink)}&text=Open%20an%20account%20with%20Arihant%20Capital%20using%20my%20referral%20link!`, '_blank'); } },
        { name: 'Messages', icon: messagesIcon, action: () => { window.open(`sms:&body=Here's my referral link for Arihant Capital: ${encodeURIComponent(referralLink)}`, '_blank'); } },
    ];

    return (
        <SharedLayout>
            {/* CHANGE 1: Reduced mt-14 to mt-6 for mobile to reduce gap to image */}
            <div className="flex justify-center mt-6 sm:mt-14 px-4 sm:px-6 w-full">
                <div
                    // CHANGE 2: Reduced p-6 to p-4 for mobile to minimize card vertical space
                    className="bg-white shadow-xl border border-gray-300 rounded-2xl w-full max-w-md
                               p-4 sm:p-8 flex flex-col items-center gap-2"
                >
                    
                    {/* QR Image - no changes needed here, already optimized */}
                    <div className="w-full max-w-[120px] sm:max-w-[100px] flex justify-center">
                        <img
                            src={acml}
                            alt="Arihant Capital QR"
                            className="w-full rounded-l rounded-r h-auto object-contain"
                            onError={(e) => {
                                e.target.onerror = null;
                                e.target.src = 'https://placehold.co/150x150/cccccc/000000?text=QR+Code+Not+Found';
                            }}
                        />
                    </div>
                    

                    {/* Ask a friend to scan your referral QR code... text block */}
                    <div className="w-full text-center">
                        <h3 className="sm:text-md font-medium text-[#434343] leading-5 ">
                            Ask a friend to scan your referral <br /> QR code 
                            and register with ArihantCapital
                        </h3>

                        <p
                            className="text-center font-normal text-sm leading-normal"
                            style={{ color: 'rgba(67, 67, 67, 0.64)', fontFamily: '"Futura PT", sans-serif' }}
                        >
                            & start earning money every time your friend trades
                        </p>
                        {/* CHANGE 3: Reduced mb-4 mt-5 to mb-3 mt-3 for mobile green line */}
                        <div className="w-10 h-1 bg-[#34b350] mx-auto mb-3 mt-3 rounded-2xl sm:mb-6 sm:mt-5"></div>

                        {/* Share QR Button */}
                        {/* CHANGE 4: Reduced mt-4 to mt-3 for mobile Share QR button */}
                        <button
                            onClick={() => setShowShareModal(true)}
                            className="text-white px-5 sm:px-6 py-3 flex items-center justify-center space-x-2 mx-auto transition-colors duration-200 shadow-md hover:shadow-lg mt-3 sm:mt-4"
                            style={{
                                borderRadius: '100px',
                                background: 'linear-gradient(270deg, #34B350 0%, #76D78A 100%)'
                            }}
                        > 
                            <Share2 className="w-4 h-4 sm:w-5 sm:h-5" />
                            <span className="font-medium text-sm sm:text-base">Share QR</span>
                        </button> 
                    </div>


                    {/* Referral Code Box */}
                    {/* CHANGE 5: Reduced mb-2 to mb-1 for mobile referral code box */}
                    <div className="flex justify-between items-center mt-2 bg-purple-100 border-2 border-dashed border-purple-300 rounded-lg px-3 py-2 mb-1 sm:mb-4 w-full">
                        <span className="text-purple-800 text-xs sm:text-sm font-mono font-medium tracking-wider truncate flex-grow text-left">
                            {referralCode}
                        </span>

                        <button
                            onClick={handleCopyReferralCode}
                            className="text-purple-600 hover:text-purple-800 transition-colors duration-200 p-1 ml-2"
                            title="Copy referral code"
                        >
                            <Copy className="w-4 h-4 sm:w-5 sm:h-5" />
                        </button>
                    </div>

                    {copiedReferralCode && (
                        // CHANGE 6: Reduced mb-2 to mb-1 for mobile copied message
                        <p className="text-green-600 text-xs sm:text-sm mb-1 sm:mb-4 text-center animate-fade-in">
                            Referral code copied to clipboard!
                        </p>
                    )}


                    {/* Terms & Conditions */}
                    {/* CHANGE 7: Reduced mt-4 to mt-2 for mobile T&C link */}
                    <p className="text-[0.65rem] sm:text-xs text-gray-500 text-center break-words mt-2 sm:mt-4">
                        By referring a friend you agree to our{' '}
                        <Link to="https://refer.arihantcapital.com/Home/TermsandCondition" target="_blank" className="text-green-600 hover:text-green-700 underline focus:outline-none focus:ring-2 focus:ring-green-300 rounded-sm">
                            Terms & Conditions
                        </Link>
                    </p>

                    {/* Track Status and Need Help? Links - Reordered and with separator */}
                    {/* CHANGE 8: Reduced mt-4 to mt-2 and pt-4 to pt-3 for mobile track status/help section */}
                    <div className="mt-2 border-t border-gray-200 w-full pt-3 sm:mt-4 sm:pt-4">
                        <div className="flex justify-center items-center w-full space-x-2">
                            <Link
                                target="_blank"
                                to="/track-status" // Replace with your actual track status URL/route
                                className="text-xs font-medium hover:underline"
                                style={{ color: 'rgba(52, 179, 80, 1)' }}
                            >
                                Track Status
                            </Link>
                            <span className="text-gray-400 text-xs">|</span> {/* Separator */}
                            <Link
                                target="_blank"
                                to="https://support.arihantcapital.com/support/solutions/33000138462"
                                className="text-xs font-medium hover:underline"
                                style={{ color: 'rgba(52, 179, 80, 1)' }}
                            >
                                Need Help?
                            </Link>
                        </div>
                    </div>
                </div>
            </div>

            {/* Share QR Modal (remains largely unchanged as it's an overlay) */}
            {showShareModal && (
                <div className="fixed inset-0 bg-black/30 backdrop-blur-sm flex items-center justify-center z-50 px-4 animate-fade-in">
                    <div className="bg-white rounded-2xl p-5 sm:p-6 w-full max-w-md sm:max-w-lg mx-auto relative">
                        <div className="flex justify-between items-center mb-5">
                            <h3 className="text-lg sm:text-xl font-medium text-gray-800">Share referral QR</h3>
                            <button
                                onClick={() => setShowShareModal(false)}
                                className="text-gray-400 hover:text-gray-600 focus:outline-none focus:ring-2 focus:ring-gray-300 rounded-full"
                            >
                                <X className="w-6 h-6" />
                            </button>
                        </div>

                        <div className="grid grid-cols-4 gap-4 mb-6">
                            {socialPlatforms.map((platform, index) => (
                                <button
                                    key={index}
                                    className="w-14 h-14 sm:w-16 sm:h-16 flex flex-col items-center justify-center hover:scale-105 transition-transform group"
                                    title={`Share on ${platform.name}`}
                                    onClick={platform.action}
                                >
                                    <img
                                        src={platform.icon}
                                        alt={platform.name}
                                        className="w-10 h-10 sm:w-12 sm:h-12 object-contain rounded-lg"
                                    />
                                    <span className="text-xs text-gray-600 mt-1 group-hover:text-gray-800">{platform.name}</span>
                                </button>
                            ))}
                        </div>

                        <div className="flex items-center mb-6">
                            <div className="flex-1 h-px bg-gray-200"></div>
                            <span className="px-4 text-gray-400 text-xs sm:text-sm">OR</span>
                            <div className="flex-1 h-px bg-gray-200"></div>
                        </div>

                        <div className="text-center px-2 sm:px-0">
                            <p className="text-gray-600 mb-4 text-xs sm:text-sm">You can also copy & share the referral link</p>
                            <div className="flex items-center bg-purple-50 border border-purple-200 rounded-lg px-3 py-2">
                                <span className="flex-1 text-purple-800 text-xs sm:text-sm font-medium truncate">
                                    {referralLink}
                                </span>
                                <button
                                    onClick={handleCopyReferralLink}
                                    className="ml-2 p-1 text-purple-600 hover:text-purple-800 focus:outline-none focus:ring-2 focus:ring-purple-300 rounded-full"
                                    title="Copy referral link"
                                >
                                    <Copy className="w-4 h-4" />
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </SharedLayout>
    );
};

export default ReferFriend;