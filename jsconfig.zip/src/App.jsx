import React, { createContext, useState, useContext, useCallback, useEffect } from 'react';
import { Routes, Route, useLocation, useNavigate } from 'react-router-dom';
import Footer from "./shared/footer";
import Header from "./shared/header";

import ReferFriend from "./pages/Generatelink";
import Referhome from "./pages/Referhome";
import OtpVerificationPage from "./pages/OtpVerificationPage";
// useAuth hook from your Authcontext.jsx is retained for isAuthenticated and logout
import { useAuth } from './Authcontext.jsx';
import 'react-toastify/dist/ReactToastify.css';

import './GlobalLoader.css';

import DashboardTS from './pages/DashboardTS.jsx'; // Import the DashboardTS page
import DashboardRS from './pages/DashboardRS.jsx'; // Import the DashboardRS page

// Loader Context remains as is
export const LoaderContext = createContext();
export const useLoader = () => useContext(LoaderContext);

function App() {
    // Component to scroll to top on route change - remains as is
    const ScrollToTopOnRouteChange = () => {
        const location = useLocation();

        useEffect(() => {
            window.scrollTo({ top: 0, behavior: "smooth" });
        }, [location.pathname]);

        return null;
    };

    const location = useLocation();
    const navigate = useNavigate();

    // Auth context details - remains as is
    const { isLoading: authLoading, isAuthenticated, logout } = useAuth();

    // App loading state - remains as is
    const [appIsLoading, setAppIsLoading] = useState(false);
    const showLoader = useCallback(() => setAppIsLoading(true), []);
    const hideLoader = useCallback(() => setAppIsLoading(false), []);

    // Logout modal state - remains as is
    const [showLogoutModal, setShowLogoutModal] = useState(false);

    // --- SIMPLIFIED REDIRECTION LOGIC ---
    // This useEffect will now primarily handle the initial redirect if a user
    // becomes authenticated while on a specific entry page.
    // The main OTP success redirect will come from the OtpVerificationPage itself.
    useEffect(() => {
        // This useEffect is now simplified. It will only handle the case where
        // a user becomes authenticated and is on an 'entry route'.
        // The specific redirect after OTP verification for DashboardTS will be handled
        // by the component that calls the OtpVerificationModal (e.g., OtpVerificationPage).
        // This prevents conflicts with direct navigations after an action (like OTP verification).

        // If you need specific initial redirects based on authentication state
        // and current path, you can re-introduce more specific logic here.
        // For now, we are relying on the component-level navigation for OTP success.

        // Example: If user is authenticated and lands on '/' or '/referfriend',
        // you might want to redirect them to a dashboard.
        // For this simplified version, we are removing the complex logic
        // that was potentially overriding the OTP success redirect.

        // If isAuthenticated becomes true, and the user is on /otpverify,
        // we assume the OtpVerificationPage will handle the final redirect.
        // If they are on /track-status-login (which is now removed from routes as per instructions)
        // or /referfriend, and isAuthenticated becomes true, you might want to redirect them.
        // For now, no automatic redirects here based on isAuthenticated.
        // The component (like OtpVerificationPage) will handle its own redirects.
    }, [isAuthenticated, location.pathname, navigate]);


    // This effect handles the popstate (browser back/forward) to show logout modal - remains as is
    useEffect(() => {
        const handlePopState = (event) => {
            const isDashboardRoute = location.pathname.startsWith('/dashboard-ts') || location.pathname.startsWith('/dashboard-rs');

            if (isAuthenticated && isDashboardRoute) {
                history.pushState(null, '', location.pathname);
                setShowLogoutModal(true);
            }
        };

        if (isAuthenticated) {
            window.addEventListener('popstate', handlePopState);
        }

        return () => {
            window.removeEventListener('popstate', handlePopState);
        };
    }, [isAuthenticated, location.pathname]);

    // Logout handlers - remain as is
    const handleConfirmLogout = () => {
        setShowLogoutModal(false);
        logout();
        navigate('/'); // Redirect to home after logout
    };

    const handleCancelLogout = () => {
        setShowLogoutModal(false);
        history.pushState(null, '', location.pathname);
    };

    const isOverallLoading = authLoading || appIsLoading;

    return (
        <LoaderContext.Provider value={{ isLoading: isOverallLoading, showLoader, hideLoader }}>
            <Header currentPage={location.pathname} />
            <ScrollToTopOnRouteChange />
            <Routes>
                {/* Main Home Page */}
                <Route path="/" element={<Referhome />} />

                {/* Route for Generate Link page */}
                <Route path="/referfriend" element={<ReferFriend />} />

                {/* Route for OTP Verification Page (which contains the modal) */}
                <Route path="/otpverify" element={<OtpVerificationPage />} />

                {/* Route for DashboardTS - where user lands after successful OTP for Track Status */}
                <Route path="/dashboard-ts" element={<DashboardTS />} />

                {/* Route for DashboardRS - for Refer Friends flow */}
                <Route path="/dashboard-rs" element={<DashboardRS />} />

                {/* Wildcard route for unmatched paths, redirects to home */}
                <Route path="*" element={<Referhome />} />
            </Routes>
            <Footer />

            {/* Global Loader UI - remains as is */}
            {isOverallLoading && (
                <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/80">
                    <div className="spinner text-center">
                        <div className="ball ball-1"></div>
                        <div className="ball ball-2"></div>
                        <div className="ball ball-3"></div>
                        <div className="ball ball-4"></div>
                        <div className="loading-text text-white text-lg font-semibold animate-pulse mt-4">
                            Good things take time... Hold on..
                        </div>
                    </div>
                </div>
            )}

            {/* Logout Confirmation Modal UI - remains as is */}
            {showLogoutModal && (
                <div className="fixed inset-0 z-[10000] flex items-center justify-center bg-black bg-opacity-50">
                    <div className="bg-white p-6 rounded-lg shadow-xl max-w-sm w-full mx-4">
                        <h3 className="text-xl font-semibold text-gray-900 mb-4 text-center">Confirm Logout</h3>
                        <p className="text-gray-700 mb-6 text-center">Are you sure you want to log out?</p>
                        <div className="flex justify-end gap-3">
                            <button
                                onClick={handleCancelLogout}
                                className="px-5 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-100 transition-colors duration-200"
                            >
                                Cancel
                            </button>
                            <button
                                onClick={handleConfirmLogout}
                                className="px-5 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors duration-200"
                            >
                                Logout
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </LoaderContext.Provider>
    );
}

export default App;
