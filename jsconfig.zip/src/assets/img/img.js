import logo from "./logo.png";
import greatWork from "./Great-Place-To-Work.png";
import googleIcon from "./google-play-icon.png"
import appStoreIcon from "./app-store-icon.png"
import ruppee from "./ruppe.png"
import coinStack from "./coinbg.png"

export {
  logo,
  greatWork,
  googleIcon,
  appStoreIcon,
  ruppee,
  coinStack
};
