import { useEffect, useRef, useState } from "react";
import { logo } from "../assets/img/img"
import { ChevronDown, CreditCard, LogOut, User } from "lucide-react";
import { Link, useLocation } from "react-router-dom";

const Header = () => {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef(null);
  const location = useLocation();

  const name = sessionStorage.getItem('ClientName');

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const toggleDropdown = () => setIsDropdownOpen(!isDropdownOpen);

  const handleMenuClick = (action) => {
    setIsDropdownOpen(false);

    sessionStorage.clear();
    window.location.href = '/';

  };

  const isSimpleHeaderPage =
    location.pathname === '/' ||
    location.pathname === '/trackStatus' ||
    location.pathname === '/referfriend' ||
    location.pathname === '/refermobile' ||
    location.pathname.startsWith('/login') ||
    location.pathname.startsWith('/otp');


  return (
    <>
      {/* Changed py-2 to py-4 for increased vertical padding */}
      <header className="bg-[#35B350] text-white py-2 px-4 md:px-6 fixed top-0 left-0 w-full z-50 shadow-md">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          <Link to='/'>
            {/* Increased logo height from h-8 md:h-10 to h-10 md:h-12 */}
            <img src={logo} alt="logo" className="h-12 md:h-14" />
          </Link>
          {!isSimpleHeaderPage && (

            <div className="flex flex-row items-center gap-10">
              <div className="relative" ref={dropdownRef}>
                <button
                  onClick={toggleDropdown}
                  className="flex items-center space-x-2 text-white hover:text-green-100 px-3 py-2 rounded-md transition"
                >
                  {/* Icon */}
                  <User className="w-4 h-4 text-white" />

                  {/* Name */}
                  <span className="whitespace-nowrap font-medium">{name}</span>

                  {/* Chevron */}
                  <ChevronDown
                    className={`w-4 h-4 transition-transform duration-200 ${isDropdownOpen ? 'rotate-180' : ''
                      }`}
                  />
                </button>

                {/* Dropdown Menu */}
                {isDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-xl py-2 z-50 border border-gray-100">
                    <div className="absolute -top-1 right-6 w-2 h-2 bg-white transform rotate-45 border-l border-t border-gray-100"></div>
                    <hr className="my-2 border-gray-100" />
                    <button
                      onClick={() => handleMenuClick('Logout')}
                      className="flex items-center w-full px-4 py-3 text-sm text-red-600 hover:bg-red-50 hover:text-red-700"
                    >
                      <LogOut className="w-4 h-4 mr-3" />
                      Logout
                      <LogOut className="w-3 h-3 ml-auto" />
                    </button>
                  </div>
                )}
              </div>

            </div>
          )}
        </div>
      </header>
    </>
  )
}

export default Header;