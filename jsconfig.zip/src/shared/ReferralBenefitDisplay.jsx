// src/components/ReferralBenefitDisplay.jsx
import React from "react";
import { FaRupeeSign } from "react-icons/fa"; // Make sure this import is present

/**
 * A reusable component to display the referral benefit (e.g., coin image and brokerage text).
 * @param {object} props - The component props.
 * @param {string} props.imageSrc - The source URL for the coin image.
 */
export default function ReferralBenefitDisplay({ imageSrc }) {
  return (
    // Main container for the left column content
    // lg:pt-20 to push the content down on large screens for alignment
    // pt-8 to add padding between header and coin in mobile view (reverted from pt-0)
    // Adjusted lg:pt for overall vertical alignment of the left column
    <div className="flex flex-col items-center text-center lg:text-left py-0 px-4 bg-white lg:h-full justify-center lg:justify-start lg:pt-12 pt-8">
      {/* Coin Image */}
      {/* Removed lg:pt-12 from here as it was adding extra padding. Relying on container's lg:pt for vertical positioning. */}
      {/* Adjusted mb for better spacing with the text below */}
      <img
        src={imageSrc}
        alt="Coin Icon"
        // Responsive image width: w-32 for mobile, md:w-64, lg:w-80
        className="w-34 md:w-64 lg:pt-20 lg:w-80 mb-4 sm:mb-6 mx-auto" // Increased mb to create a bit more space below the coin
      />

      {/* Text content: "Earn 20% brokerage" */}
      {/* Removed lg:text-left to keep text centered on all screen sizes */}
      <div className="text-[#434343] text-center">
        {/* Adjusted font size for mobile (text-3xl) and added leading-snug for tighter line height */}
        <h2 className="text-3xl md:text-5xl text-center lg:text-[48px] font-semibold  sm:leading-snug">
          Earn
          <span className="ml-2 inline-flex items-baseline" style={{ color: '#34B350' }}>
            <FaRupeeSign
              className="inline-block"
              style={{
                height: '0.85em',
                width: '0.85em',
                transform: 'translateY(0.1em)',
              }}
            />
            300*
            {/* Moved (T&C Apply) inside the span and adjusted styling for better alignment */}
            <p
              className="text-[12px] font-medium ml-1 whitespace-nowrap inline-block align-super" // Use align-super for vertical alignment
              style={{ color: '#34B343' }}
            >
              (T&C Apply)
            </p>
          </span>
        </h2>
        {/* Changed mt-4 to mt-0.5 for minimal margin between the two text lines, reduced mb-4 to mb-2 for tighter spacing with the dash */}
        <p className="text-base md:text-lg lg:text-xl font-normal     letter-spacing: 1px; tracking-wider mt-0.5 mb-2">
        when your friend opens an account using your referral link!
        </p>
      </div>

      {/* Green dash for mobile view */}
      {/* Hidden on large screens (lg:hidden). Changed width from w-16 to w-14. Reduced mt-4 to mt-2 for tighter spacing. */}
      <div className="w-14 h-1 bg-[#34B350] rounded-full mt-2 lg:hidden"></div>
    </div>
  );
}