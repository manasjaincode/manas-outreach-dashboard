import axios from 'axios';

const apiClient = axios.create({
    baseURL: 'https://uatreferpartner.arihantcapital.com/api/v1',
    timeout: 30000,
    headers: {
        'Content-Type': 'application/json',
         'Authorization': `Bearer ${sessionStorage.getItem('authToken')}`,
        // It sets the token only once when the script loads, which can be stale.
        // The interceptor below will handle it dynamically for every request.
    },
});

apiClient.interceptors.request.use(
    (config) => {
        // This is the correct place to dynamically get the latest token
        const token = sessionStorage.getItem('authToken');
        if (token) {
            config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);

apiClient.interceptors.response.use(
    (response) => {
        return response;
    },
    (error) => {
        if (error.response && error.response.status === 401) {
            // This is still clearing sessionStorage twice, which is redundant but not harmful.
            // Keeping it as per your instruction to not make other changes.
            sessionStorage.clear();
            sessionStorage.clear();
            window.location.href = '/';
        }
        return Promise.reject(error);
    }
);

export default apiClient;