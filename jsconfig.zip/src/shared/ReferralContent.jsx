// src/pages/ReferralAndSharedLayout.jsx

import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Share2, Copy, X } from 'lucide-react';
import { FaRupeeSign } from 'react-icons/fa6';
import mainReferralImage from '../assets/img/Group 7726.png';
import qrCodeIcon from '../assets/img/qr-code (2) 1.svg';
import highFiveHandIcon from '../assets/img/high-five 1 (1).svg';
import discountTagIcon from '../assets/img/discount (1) 1 (1).svg';
import rightArrowCircleIcon from '../assets/img/arrow-right-circle.svg';
import acml from "../assets/img/acml.png";
import whatsappIcon from '../assets/img/icon/whatsapp.png';
import facebookIcon from '../assets/img/icon/fb.png';
import gmailIcon from '../assets/img/icon/email.png';
import linkdinIcon from '../assets/img/icon/linkdin.png';
import instagramIcon from '../assets/img/icon/instagram.png';
import twitterIcon from '../assets/img/icon/x.png';
import telegramIcon from '../assets/img/icon/telegram.png';
import messagesIcon from '../assets/img/icon/freechat.png';

const ReferralAndSharedLayout = ({ isDashboardContext = false }) => {
  const renderLeftColumn = () => (
    // Added py-4 for mobile vertical spacing, changed back to py-0 on lg
    <div className="relative w-full lg:w-1/2 flex justify-center items-center px-7 py-4 lg:py-0">
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="w-64 h-64 sm:w-80 sm:h-80 md:w-96 md:h-96 lg:w-[450px] lg:h-[450px] bg-accent-green rounded-full opacity-60 flex items-center justify-center">
          <div className="w-52 h-52 sm:w-64 sm:h-64 md:w-80 md:h-80 lg:w-[350px] lg:h-[350px] bg-gradient-to-br from-accent-green to-light-green-bg rounded-full opacity-80"></div>
        </div>
      </div>
      <img
        src={mainReferralImage}
        alt="Refer and Earn"
        className="relative z-10 max-w-[80%] h-auto"
        style={{
          width: '400.06px',
          maxHeight: 'min(440px, 60vh)',
          height: 'auto',
          flexShrink: 0,
          objectFit: 'contain'
        }}
      />
    </div>
  );

  const StepItem = ({ icon, altText, title, description }) => (
    // CRITICAL CHANGE 1: Added py-2 for smaller vertical padding on mobile, increased to py-4 on md and py-2 on lg for desktop
    <div className="flex flex-col items-center text-center max-w-[320px] flex-1 py-2 md:py-4 lg:py-2">
      <div className="w-12 h-12 md:w-16 md:h-16 rounded-full bg-accent-green flex items-center justify-center mb-1">
        <img src={icon} alt={altText} className="w-6 h-6 md:w-8 md:h-8 object-contain" />
      </div>
      <p className="text-dark-text font-futura text-base font-medium leading-normal sm:text-lg">
        {title}
      </p>
      <p className="text-light-text font-roboto text-xs font-normal leading-normal mt-0.5 sm:text-sm">
        {description}
      </p>
    </div>
  );

  const [referralCode, setReferralCode] = useState('MMVYC328');
  const [referralLink, setReferralLink] = useState('https://acml.link.example/loginusingmyreferrallink');
  const [copiedReferralCode, setCopiedReferralCode] = useState(false);
  const [showShareModal, setShowShareModal] = useState(false);

  const handleCopyReferralCode = () => {
    navigator.clipboard.writeText(referralCode)
      .then(() => {
        setCopiedReferralCode(true);
        setTimeout(() => setCopiedReferralCode(false), 2000);
      })
      .catch(err => {
        console.error('Failed to copy referral code:', err);
        document.execCommand('copy', false, referralCode);
        setCopiedReferralCode(true);
        setTimeout(() => setCopiedReferralCode(false), 2000);
      });
  };

  const handleCopyReferralLink = () => {
    navigator.clipboard.writeText(referralLink)
      .then(() => {
        console.log('Referral link copied!');
      })
      .catch(err => {
        console.error('Failed to copy referral link:', err);
        document.execCommand('copy', false, referralLink);
        console.log('Referral link copied!');
      });
  };

  const socialPlatforms = [
    { name: 'WhatsApp', icon: whatsappIcon, action: () => { window.open(`https://wa.me/?text=${encodeURIComponent(referralLink)}`, '_blank'); } },
    { name: 'Facebook', icon: facebookIcon, action: () => { window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(referralLink)}`, '_blank'); } },
    { name: 'Gmail', icon: gmailIcon, action: () => { window.open(`mailto:?subject=Check out Arihant Capital!&body=Here's my referral link: ${encodeURIComponent(referralLink)}`, '_blank'); } },
    { name: 'LinkedIn', icon: linkdinIcon, action: () => { window.open(`https://www.linkedin.com/shareArticle?mini=true&url=${encodeURIComponent(referralLink)}&title=Join%20Arihant%20Capital&summary=Open%20an%20account%20with%20my%20referral%20link!`, '_blank'); } },
    { name: 'Instagram', icon: instagramIcon, action: () => alert('Instagram sharing usually requires a direct share from the app or specific API integration.') },
    { name: 'Twitter', icon: twitterIcon, action: () => { window.open(`https://twitter.com/intent/tweet?url=${encodeURIComponent(referralLink)}&text=Open%20an%20account%20with%20Arihant%20Capital%20using%20my%20referral%20link!`, '_blank'); } },
    { name: 'Telegram', icon: telegramIcon, action: () => { window.open(`https://t.me/share/url?url=${encodeURIComponent(referralLink)}&text=Open%20an%20account%20with%20Arihant%20Capital%20using%20my%20referral%20link!`, '_blank'); } },
    { name: 'Messages', icon: messagesIcon, action: () => { window.open(`sms:&body=Here's my referral link for Arihant Capital: ${encodeURIComponent(referralLink)}`, '_blank'); } },
  ];

  const mainContentClasses = `
    w-full max-w-md
    flex flex-col items-center gap-1.5 sm:gap-2
    ${isDashboardContext
      // CRITICAL CHANGE 2: Adjusted mobile padding for the white content box
      ? 'bg-white p-2 mt-1 sm:p-3' // Added sm:p-3 to prevent it from being too small on slightly larger mobile views
      : 'bg-white rounded-2xl p-3 mt-1' // p-3 is fine for rounded box, keep it consistent
    }
  `;

  return (
    // CRITICAL CHANGE 3: Added py-4 to the main container for overall mobile vertical padding
    <div
    >
      <header className="w-full max-w-7xl mb-0">
        {/* Placeholder for ArihantCapital logo and tabs */}
      </header>

      {/* Added mt-4 for mobile spacing between header and main content, reset to mt-0 on lg */}
      <main className="flex flex-col lg:flex-row items-start justify-center gap-2 lg:gap-4 w-full max-w-7xl mt-4 lg:mt-0 flex-grow-0">
        {renderLeftColumn()}

        <div className="w-full lg:w-1/2 flex justify-center">
          <div className="flex justify-center px-2 sm:px-4 w-full">
            <div className={mainContentClasses}>
              {/* QR Image */}
              <div className="w-full max-w-[100px] sm:max-w-[80px] flex justify-center mb-1">
                <img
                  src={acml}
                  alt="Arihant Capital QR"
                  className="w-full rounded-l rounded-r h-auto object-contain"
                  onError={(e) => {
                    e.target.onerror = null;
                    e.target.src = 'https://placehold.co/150x150/cccccc/000000?text=QR+Code+Not+Found';
                  }}
                />
              </div>

              {/* Ask a friend to scan your referral QR code... text block */}
              <div className="w-full text-center">
                {/* CRITICAL CHANGE 4: Adjusted heading font size for extra small screens */}
                <h3 className="text-sm sm:text-base font-medium text-[#434343] leading-tight mb-1">
                  Ask a friend to scan your referral <br /> QR code
                  and register with ArihantCapital
                </h3>
                <p
                  className="text-center font-normal text-xs leading-snug"
                  style={{ color: 'rgba(67, 67, 67, 0.64)', fontFamily: '"Futura PT", sans-serif' }}
                >
                  & start earning money every time your friend trades
                </p>
                <div className="w-8 h-0.5 bg-[#34b350] mx-auto mb-2 mt-2 rounded-2xl sm:mb-3"></div>

                {/* Share QR Button */}
                <button
                  onClick={() => setShowShareModal(true)}
                  className="text-white px-4 sm:px-5 py-2 flex items-center justify-center space-x-1.5 mx-auto transition-colors duration-200 shadow-md hover:shadow-lg mt-2 text-sm sm:text-base"
                  style={{
                    borderRadius: '100px',
                    background: 'linear-gradient(270deg, #34B350 0%, #76D78A 100%)'
                  }}
                >
                  <Share2 className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                  <span className="font-medium text-sm sm:text-base">Share QR</span>
                </button>
              </div>

              {/* Referral Code Box */}
              <div className="flex justify-between items-center mt-2 bg-purple-100 border-2 border-dashed border-purple-300 rounded-lg px-2 py-1.5 mb-2 w-full">
                <span className="text-purple-800 text-xs font-mono font-medium tracking-wider truncate flex-grow text-left">
                  {referralCode}
                </span>
                <button
                  onClick={handleCopyReferralCode}
                  className="text-purple-600 hover:text-purple-800 transition-colors duration-200 p-0.5 ml-1"
                  title="Copy referral code"
                >
                  <Copy className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                </button>
              </div>

              {copiedReferralCode && (
                <p className="text-green-600 text-xs mb-1 text-center animate-fade-in">
                  Referral code copied to clipboard!
                </p>
              )}

              {/* Terms & Conditions */}
              <p className="text-[0.6rem] sm:text-xs text-gray-500 text-center break-words mt-1">
                By referring a friend you agree to our{' '}
                <Link to="https://refer.arihantcapital.com/Home/TermsandCondition" target="_blank" className="text-green-600 hover:text-green-700 underline focus:outline-none focus:ring-2 focus:ring-green-300 rounded-sm">
                  Terms & Conditions
                </Link>
              </p>

              {/* Track Status and Need Help? Links */}
              <div className="mt-1 border-t border-gray-200 w-full pt-1">
                <div className="flex justify-center items-center w-full space-x-1.5">
                  <Link
                    target="_blank"
                    to="/track-status"
                    className="text-xs font-medium hover:underline"
                    style={{ color: 'rgba(52, 179, 80, 1)' }}
                  >
                    Track Status
                  </Link>
                  <span className="text-gray-400 text-xs">|</span>
                  <Link
                    target="_blank"
                    to="https://support.arihantcapital.com/support/solutions/33000138462"
                    className="text-xs font-medium hover:underline"
                    style={{ color: 'rgba(52, 179, 80, 1)' }}
                  >
                    Need Help?
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Steps Section */}
      {/* Added mt-4 for mobile spacing, changed back to mt-0 on lg */}
      <section className="w-full flex flex-col items-center px-4 sm:px-6 lg:px-0 mt-4 lg:mt-0">
        {/* CRITICAL CHANGE 5: Adjusted padding for the main steps container for better mobile spacing */}
        <div className="w-full max-w-[1296px] bg-[rgba(52,179,80,0.16)] rounded-2xl px-2 py-2 sm:px-4 sm:py-3 flex flex-col md:flex-row items-center justify-around gap-2 md:gap-4 shadow-sm">
          <StepItem
            icon={qrCodeIcon}
            altText="QR Code"
            title="Generate & share link or QR code"
            description="Send your referral link or QR code to a friend who's interested in ArihantPlus."
          />
          <div className="hidden md:flex flex-shrink-0">
            <img src={rightArrowCircleIcon} alt="Next Step Arrow" className="w-6 h-6 object-contain" />
          </div>
          <div className="md:hidden w-px h-8 bg-gray-300"></div>

          <StepItem
            icon={highFiveHandIcon}
            altText="High Five"
            title="Have a friend sign up"
            description="Make sure they sign up using the link and complete the eKYC process to activate account"
          />
          <div className="hidden md:flex flex-shrink-0">
            <img src={rightArrowCircleIcon} alt="Next Step Arrow" className="w-6 h-6 object-contain" />
          </div>
          <div className="md:hidden w-px h-8 bg-gray-300"></div>

          <StepItem
            icon={discountTagIcon}
            altText="Discount"
            title="Earn ₹300*"
            description="For every friend that opens an account using your referral link, you make ₹300!"
          />
        </div>

        {/* Terms & Conditions for steps */}
        <div className="w-full max-w-[1296px] mx-auto mt-1 px-4 mb-2">
          <p className="text-light-text font-roboto text-xs text-left">
            * Terms & Conditions applied.
          </p>
        </div>
      </section>

      {/* Share QR Modal (no changes needed here for layout) */}
      {showShareModal && (
        <div className="fixed inset-0 bg-black/30 backdrop-blur-sm flex items-center justify-center z-50 px-4 animate-fade-in">
          <div className="bg-white rounded-2xl p-5 sm:p-6 w-full max-w-md sm:max-w-lg mx-auto relative">
            <div className="flex justify-between items-center mb-5">
              <h3 className="text-lg sm:text-xl font-medium text-gray-800">Share referral QR</h3>
              <button
                onClick={() => setShowShareModal(false)}
                className="text-gray-400 hover:text-gray-600 focus:outline-none focus:ring-2 focus:ring-gray-300 rounded-full"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="grid grid-cols-4 gap-4 mb-6">
              {socialPlatforms.map((platform, index) => (
                <button
                  key={index}
                  className="w-14 h-14 sm:w-16 sm:h-16 flex flex-col items-center justify-center hover:scale-105 transition-transform group"
                  title={`Share on ${platform.name}`}
                  onClick={platform.action}
                >
                  <img
                    src={platform.icon}
                    alt={platform.name}
                    className="w-10 h-10 sm:w-12 sm:h-12 object-contain rounded-lg"
                  />
                  <span className="text-xs text-gray-600 mt-1 group-hover:text-gray-800">{platform.name}</span>
                </button>
              ))}
            </div>

            <div className="flex items-center mb-6">
              <div className="flex-1 h-px bg-gray-200"></div>
              <span className="px-4 text-gray-400 text-xs sm:text-sm">OR</span>
              <div className="flex-1 h-px bg-gray-200"></div>
            </div>

            <div className="text-center px-2 sm:px-0">
              <p className="text-gray-600 mb-4 text-xs sm:text-sm">You can also copy & share the referral link</p>
              <div className="flex items-center bg-purple-50 border border-purple-200 rounded-lg px-3 py-2">
                <span className="flex-1 text-purple-800 text-xs sm:text-sm font-medium truncate">
                  {referralLink}
                </span>
                <button
                  onClick={handleCopyReferralLink}
                  className="ml-2 p-1 text-purple-600 hover:text-purple-800 focus:outline-none focus:ring-2 focus:ring-purple-300 rounded-full"
                  title="Copy referral link"
                >
                  <Copy className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ReferralAndSharedLayout;