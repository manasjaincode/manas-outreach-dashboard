// src/components/SharedLayout.jsx
import React from 'react';
import { FaRupeeSign } from 'react-icons/fa6';
import mainReferralImage from '../assets/img/Group 7726.png';
import qrCodeIcon from '../assets/img/qr-code (2) 1.svg';
import highFiveHandIcon from '../assets/img/high-five 1 (1).svg';
import discountTagIcon from '../assets/img/discount (1) 1 (1).svg';
import rightArrowCircleIcon from '../assets/img/arrow-right-circle.svg';

const SharedLayout = ({ children }) => {

  const renderLeftColumn = () => (
    <div className="relative w-full lg:w-1/2 flex justify-center items-center p-4 sm:p-6 lg:p-7">
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="w-64 h-64 sm:w-80 sm:h-80 md:w-96 md:h-96 lg:w-[450px] lg:h-[450px] bg-accent-green rounded-full opacity-60 flex items-center justify-center">
          <div className="w-52 h-52 sm:w-64 sm:h-64 md:w-80 md:h-80 lg:w-[350px] lg:h-[350px] bg-gradient-to-br from-accent-green to-light-green-bg rounded-full opacity-80"></div>
        </div>
      </div>
      <img
        src={mainReferralImage}
        alt="Refer and Earn"
        className="relative z-10 w-full max-w-[65%] sm:max-w-[80%] mx-auto h-auto object-contain flex-shrink-0 lg:w-[400px] lg:h-[520px] lg:max-w-none"
      />
    </div>
  );

  const StepItem = ({ icon, altText, title, description }) => (
    <div className="flex flex-col items-center text-center flex-1 px-2 py-2">
      <div className="w-10 h-10 sm:w-12 sm:h-12 md:w-16 md:h-16 rounded-full bg-accent-green flex items-center justify-center mb-1 sm:mb-2">
        <img src={icon} alt={altText} className="w-5 h-5 sm:w-6 sm:h-6 md:w-8 md:h-8 object-contain" />
      </div>
      <p className="text-dark-text font-futura text-lg font-medium leading-normal">
        {title}
      </p>
      <p className="text-light-text font-roboto text-sm font-normal leading-normal mt-1">
        {description}
      </p>
    </div>
  );

  return (
    <div
      className="min-h-screen font-futura flex flex-col items-center pt-8 pb-4 px-4 sm:px-6 lg:px-8 lg:pt-12"
      style={{
        background: 'linear-gradient(to bottom, #E5FFE2, #B5F8DB)'
      }}
    >

      <header className="w-full max-w-7xl mb-6">
        {/* Potentially add logo/navigation here if needed */}
      </header>

      {/* CHANGE: Changed lg:items-start to lg:items-center to vertically align image and card */}
      <main className="flex flex-col lg:flex-row items-center justify-center gap-4 lg:gap-8 w-full max-w-7xl flex-grow">
        {renderLeftColumn()}

        <div className="w-full lg:w-1/2 flex justify-center py-4">
          {children}
        </div>
      </main>

      <section className="w-full flex flex-col items-center px-4 sm:px-6 lg:px-0 mt-8">
        <div className="w-full max-w-[1296px] bg-[rgba(52,179,80,0.16)] rounded-2xl
                       px-4 py-4 sm:px-6 md:px-10 lg:px-10
                       flex flex-col md:flex-row items-center justify-around gap-3 md:gap-[24px] shadow-sm">

          <StepItem
            icon={qrCodeIcon}
            altText="QR Code"
            title="Generate & share link or QR code"
            description="Send your referral link or QR code to a friend who's interested in ArihantPlus."
          />

          <div className="hidden md:flex flex-shrink-0">
            <img src={rightArrowCircleIcon} alt="Next Step Arrow" className="w-8 h-8 object-contain" />
          </div>

          <StepItem
            icon={highFiveHandIcon}
            altText="High Five"
            title="Have a friend sign up"
            description="Make sure they sign up using the link and complete the eKYC process to activate account"
          />

          <div className="hidden md:flex flex-shrink-0">
            <img src={rightArrowCircleIcon} alt="Next Step Arrow" className="w-8 h-8 object-contain" />
          </div>

          <StepItem
            icon={discountTagIcon}
            altText="Discount"
            title="Earn ₹300*"
            description="For every friend that opens an account using your referral link, you make ₹300!"
          />
        </div>

        <div className="w-full max-w-[1296px] mx-auto mt-4 px-4 sm:px-6 md:px-10 lg:px-10">
          <p className="text-light-text font-roboto text-xs text-left">
            * Terms & Conditions applied.
          </p>
        </div>
      </section>
    </div>
  );
};

export default SharedLayout;