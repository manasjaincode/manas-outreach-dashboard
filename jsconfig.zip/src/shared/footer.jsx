import { Facebook, Instagram, Linkedin, X, Youtube } from 'lucide-react'
import React from 'react'
import { appStoreIcon, googleIcon, greatWork } from '../assets/img/img'
import { Link } from 'react-router-dom' 
const Footer = () => {
  
  return (
    <footer className="bg-[#e9ffe8] text-green-700 px-6 py-10 text-sm">
      <div className="max-w-7xl mx-auto grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-6">
        {/* Product */}
        <div>
          {/* Changed text-lg to text-[#2eb34b] */}
          <h3 className="font-bold text-lg mb-2 text-[#2eb34b]">Product</h3>
          <ul className="space-y-3">
            <Link to="https://www.arihantcapital.com/equity-trading-account" target='_blank'>
              <li className="hover:text-green-600 cursor-pointer transition-colors duration-200 p-1">Equity</li>
            </Link>
            <Link to="https://www.arihantcapital.com/invest-in-mutual-funds" target='_blank'>
              <li className="hover:text-green-600 cursor-pointer transition-colors duration-200 p-1">Mutual Funds</li>
            </Link>
            <Link to="https://www.arihantcapital.com/national-pension-scheme-nps" target='_blank'>
              <li className="hover:text-green-600 cursor-pointer transition-colors duration-200 p-1">NPS</li>
            </Link>
            <Link to="https://www.arihantcapital.com/fixed-income" target='_blank'>
              <li className="hover:text-green-600 cursor-pointer transition-colors duration-200 p-1">Fixed Income</li>
            </Link>
          </ul>
          <img src={greatWork} alt="Great Place To Work" className="w-25 mt-3" />
        </div>

        {/* Trading + Useful Links */}
        <div>
          {/* Changed text-lg to text-[#2eb34b] */}
          <h3 className="font-bold text-lg mb-2 text-[#2eb34b]">Trading</h3>
          <ul className="space-y-3 mb-4">
            
            <Link to="https://www.arihantcapital.com/online-trading-platform" target='_blank'> <li className="hover:text-green-600 cursor-pointer transition-colors duration-200 p-1">Trading Platforms</li></Link>
            <Link to="https://www.arihantcapital.com/margin-calculator" target='_blank'> <li className="hover:text-green-600 cursor-pointer transition-colors duration-200 p-1">Margin Calculator</li></Link>
          </ul>
          {/* Changed text-lg to text-[#2eb34b] */}
          <h3 className="font-bold text-lg mb-2 text-[#2eb34b]">Useful links</h3>
          <ul className="space-y-3">
            
            <Link to="https://evoting.cdslindia.com/Evoting/EvotingLogin" target='_blank'> <li className="hover:text-green-600 cursor-pointer transition-colors duration-200 p-1">CDSL eVoting</li></Link>
            <Link to="https://www.evoting.nsdl.com/" target='_blank'> <li className="hover:text-green-600 cursor-pointer transition-colors duration-200 p-1">NSDL eVoting</li></Link>
            <Link to="https://refer.arihantcapital.com/" target='_blank'> <li className="hover:text-green-600 cursor-pointer transition-colors duration-200 p-1">Refer & Earn</li></Link>
          </ul>
        </div>

        {/* Who we are */}
        <div>
          {/* Changed text-lg to text-[#2eb34b] */}
          <h3 className="font-bold text-lg mb-2 text-[#2eb34b]">Who we are</h3>
          <ul className="space-y-3">
          
            <Link to="https://www.arihantcapital.com/about-us" target='_blank'> <li className="hover:text-green-600 cursor-pointer transition-colors duration-200 p-1">About Us</li></Link>
            <Link to="https://www.arihantcapital.com/investor-relations" target='_blank'> <li className="hover:text-green-600 cursor-pointer transition-colors duration-200 p-1">Investor Relations</li></Link>
            <Link to="https://www.arihantcapital.com/careers" target='_blank'> <li className="hover:text-green-600 cursor-pointer transition-colors duration-200 p-1">Work at Arihant</li></Link>
            <Link to="https://www.arihantcapital.com/institutional-broking" target='_blank'> <li className="hover:text-green-600 cursor-pointer transition-colors duration-200 p-1">Institutional Equities</li></Link>
            <Link to="http://arihantcapital.com/merchant-banking" target='_blank'> <li className="hover:text-green-600 cursor-pointer transition-colors duration-200 p-1">Merchant Banking</li></Link>
          </ul>
        </div>

        {/* Connect with us */}
        <div>
          {/* Changed text-lg to text-[#2eb34b] */}
          <h3 className="font-bold text-lg mb-2 text-[#2eb34b]">Connect with us</h3>
          <ul className="space-y-3">
          
            <Link to="https://ekyc.arihantcapital.com/" target='_blank'> <li className="hover:text-green-600 cursor-pointer transition-colors duration-200 p-1">Open an account</li></Link>
            <Link to="https://www.arihantcapital.com/invester-charter" target='_blank'> <li className="hover:text-green-600 cursor-pointer transition-colors duration-200 p-1">Invester Charter</li></Link>
            <Link to="https://www.arihantcapital.com/contact-us" target='_blank'> <li className="hover:text-green-600 cursor-pointer transition-colors duration-200 p-1">Contact Us</li></Link>
            <Link to="https://support.arihantcapital.com/support/home" target='_blank'> <li className="hover:text-green-600 cursor-pointer transition-colors duration-200 p-1">Support</li></Link>
            <Link to="https://www.arihantcapital.com/investor-attention" target='_blank'> <li className="hover:text-green-600 cursor-pointer transition-colors duration-200 p-1">Attention Investors</li></Link>
            <Link to="https://www.arihantcapital.com/fund-transfer" target='_blank'> <li className="hover:text-green-600 cursor-pointer transition-colors duration-200 p-1">Fund Transfer</li></Link>
            <Link to="https://www.arihantcapital.com/business-partner" target='_blank'> <li className="hover:text-green-600 cursor-pointer transition-colors duration-200 p-1">Partner with us</li></Link>
          </ul>
        </div>

        {/* Newsletter + Social */}
        <div className="col-span-2 md:col-span-1">
          {/* Changed text-lg to text-[#2eb34b] */}
          <h3 className="font-bold text-lg mb-2 text-[#2eb34b]">
            Stay on top of the markets with our bite-sized newsletter delivered right to your Inbox!
          </h3>
          <div className="flex mt-4 rounded overflow-hidden border border-gray-300">
            <input
              type="text"
              placeholder="Open an account"
              className="flex-1 px-3 py-2 focus:outline-none"
            />
            <button className="bg-[#35B350] text-white px-4 text-xl font-bold">›</button>
          </div>

          {/* Social icons */}
          <div className="flex items-center space-x-4 mt-4 text-xl text-green-700">
            <Link
              to="https://www.facebook.com/arihantcapitalmarket"
              target='_blank'
              rel="noopener noreferrer"
              aria-label="Facebook"
            >
              <Facebook className="w-6 h-6" />
            </Link>
            <Link
              to="https://www.instagram.com/arihant_plus/#" 
              target='_blank'
              rel="noopener noreferrer"
              aria-label="Instagram"
            >
              <Instagram className="w-6 h-6" />
            </Link>
            <Link
              to="https://www.linkedin.com/company/arihant-capital-markets-ltd" 
              target='_blank'
              rel="noopener noreferrer"
              aria-label="LinkedIn"
            >
              <Linkedin className="w-6 h-6" />
            </Link>
            <Link
              to="https://x.com/ArihantPlus" 
              target='_blank'
              rel="noopener noreferrer"
              aria-label="X"
            >
              <span className="w-6 h-6 flex items-center justify-center text-2xl font-bold leading-none">
                X
              </span>
            </Link>
            <Link
              to="https://www.youtube.com/channel/UCrPcG3wkHygflvEIMcb_I3Q" 
              target='_blank'
              rel="noopener noreferrer"
              aria-label="YouTube"
            >
              <Youtube className="w-6 h-6" />
            </Link>
          </div>

          {/* App Store Buttons */}

<div className="flex space-x-3 mt-4">
  <Link to="https://play.google.com/store/apps/details?id=com.msf.acml&hl=en_IN">
    <img src={googleIcon} alt="Google Play" className="h-10" />
  </Link>
  <Link to="https://apps.apple.com/in/app/arihant-plus/id1643484698">
    <img src={appStoreIcon} alt="App Store" className="h-10" />
  </Link>
</div>

        </div>

      </div>
      <div className="bg-[#eaffdd] text-[#1b4d2d] px-4 md:px-16 py-10 text-sm leading-relaxed space-y-6">
        {/* Changed text-xl to text-[#2eb34b] */}
        <h2 className="font-bold text-center text-lg md:text-xl text-[#2eb34b]">
          #1011 Solitaire Corporate Park, Andheri Ghatkopar Link Road, Chakala, Andheri (E), Mumbai - 400093.
        </h2>

        <hr className="border border-green-200 my-4" />

        <p>
          Arihant Capital Markets Limited is a SEBI registered stock broker and depository participant.
          SEBI Registration number for NSE & BSE :- INZ000180939; NSDL - IN-DP-127-2015 DP ID-IN301983;
          CDSL DP ID-43000; NCDEX - 01274; MCX - 56565; AMFI - ARN 15114; SEBI Merchant Banking Reg. No. - MB INM000011070;
          SEBI Research Analyst Reg. No. - INH000002764. <span className="font-semibold">Registered Address:</span> 6, Lad Colony, Y.N. Road, Indore – 452001.
          <span className="font-semibold">Corporate office address:</span> #1011 Solitaire Corporate Park, Andheri Ghatkopar Link Road, Chakala, Andheri (E), Mumbai - 400093.
        </p>

        <p>
          Please carefully read the risk disclosure document as prescribed by SEBI and Do’s & Don’ts by NSE, BSE, NCDEX & MCX.
          For any complaints regarding securities broking, pls write to <a href="mailto:complaint@arihantcapital.com" className="underline text-green-700">complaint@arihantcapital.com</a> and for DP write to <a href="mailto:depository@arihantcapital.com" className="underline text-green-700">depository@arihantcapital.com</a>.
        </p>

        <p>
          If you want to register your complaints through SEBI Score Portal please
          <a href="https://scores.sebi.gov.in/" className="text-orange-600 font-medium ml-1">click here</a>.
          Mandatory details for filing complaints on SCORES: Name, PAN, Address, Mobile Number, E-mail ID. Benefits: Effective Communication, Speedy redressal of the grievances.
        </p>

        <p>
          Investments in securities market are subject to market risks; read all the related documents carefully before investing.
          <br />
          Disclaimer: Arihant Capital Markets Limited is engaged in client based and proprietary trading on various exchanges.
        </p>

        <div>
          {/* Changed text-[#1b4d2d] to text-[#2eb34b] */}
          <h3 className="text-base md:text-lg font-bold mt-8 text-[#2eb34b]">ATTENTION INVESTORS :</h3>
          <ul className="list-disc list-inside space-y-2 mt-2">
            <li>
              KYC is one time exercise while dealing in securities markets – once KYC is done through a SEBI registered intermediary (Broker, DP, Mutual Fund etc.),
              you need not undergo the same process again when you approach another intermediary.
            </li>
            <li>
              For Stock Broking Transaction 'Prevent unauthorised transactions in your account - update your mobile numbers/email IDs with your stockbrokers.
              Receive information of your transactions directly from Exchange on your mobile/email at the end of the day.
            </li>
            <li>
              For Depository Transaction 'Prevent Unauthorized Transactions in your demat account - Update your Mobile Number with your Depository Participant. Receive alerts on your Registered Mobile for all debit and other important transactions in your demat account directly from CDSL/NSDL on the same day.
            </li>
            <li>
              If you are subscribing to an IPO, there is no need to issue cheques. Just write the bank account number and sign in the application form to authorise your bank to make payment in case of allotment. No worries for refund as the money remains in investor's account.
            </li>
            <li>
              Investors should be cautious on unsolicited emails and SMS advising to buy, sell or hold securities and trade only on the basis of informed decision. Investors are advised to invest after conducting appropriate analysis of respective companies and not to blindly follow unfounded rumours, tips etc. Further, you are also requested to share your knowledge or evidence of systemic wrongdoing, potential frauds or unethical behaviour through the anonymous portal facility provided on BSE & NSE website.
            </li>
            <li>
              Registration granted by SEBI and certification from NISM in no way guarantee performance of the intermediary or provide any assurance of returns to investors.
            </li>
          </ul>

          <div>
            {/* Changed text-base md:text-lg to text-[#2eb34b] */}
            <h3 className="font-semibold text-base md:text-lg mt-4 mb-2 text-[#2eb34b]">Awareness regarding guidelines of margin collection:</h3>
            <ol className="list-decimal list-inside space-y-2">
              <li>
                Stock brokers can accept securities as margins from clients only by way of pledge in the depository system w.e.f September 01, 2020.
              </li>
              <li>
                Update your e-mail and phone number with your stock broker / depository participant and receive OTP directly from depository on your e-mail and/or mobile number to create pledge.
              </li>
              <li>
                Check your securities / MF / bonds in the consolidated account statement issued by NSDL/CDSL every month.
              </li>
            </ol>
            <p className="my-5 text-m">Issued in the interest of investors</p>
          </div>

          <div className="flex flex-col md:flex-row justify-between items-center border-t pt-5 text-sm">
          

          <div className="text-orange-600 space-x-2 mb-2 md:mb-0">
           <Link
      to="https://www.arihantcapital.com/privacyandsecurity"
      target="_blank"
      className="hover:underline"
    >
      Privacy
    </Link>
            <span>|</span>
            <Link to="/terms" className="hover:underline">Terms & Conditions</Link>
          </div>

            <p className="text-center md:text-right">
              Copyright © 2025 Arihant Capital Markets Ltd. All rights Reserved.
            </p>
          </div>

        </div>
      </div>

    </footer>

  )
}

export default Footer;