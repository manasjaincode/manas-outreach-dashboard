import React, { useEffect, useState } from 'react';

function ToastMessage({ message, type, onClose }) {
    const [isVisible, setIsVisible] = useState(true);

    // Auto-hide the toast after 5 seconds (adjust as needed)
    useEffect(() => {
        const timer = setTimeout(() => {
            setIsVisible(false);
            if (onClose) {
                onClose(); // Call the parent's onClose handler
            }
        }, 5000); // 5 seconds

        return () => clearTimeout(timer); // Cleanup on unmount
    }, [onClose]);

    if (!isVisible || !message) {
        return null;
    }

    const bgColor = type === 'error' ? 'bg-red-600' : 'bg-green-600';
    const title = type === 'error' ? 'Error' : 'Success';

    // SVG icon for error (circle with cross line) - Based on your image
    const errorIcon = (
        <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            strokeWidth="2.5"
            stroke="currentColor"
            className="w-full h-full"
            style={{ color: 'white' }}
        >
            {/* Circle */}
            <circle cx="12" cy="12" r="10" />
            {/* Diagonal line */}
            <line x1="4.5" y1="19.5" x2="19.5" y2="4.5" />
        </svg>
    );

    // SVG icon for success (check in circle)
    const successIcon = (
        <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            strokeWidth="2.5"
            stroke="currentColor"
            className="w-full h-full"
            style={{ color: 'white' }}
        >
            <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
    );

    // --- MODIFIED LOGIC FOR DISPLAY MESSAGE ---
    let renderedMessage;
    if (type === 'error' && message.includes("Did you enter the wrong OTP?")) {
        // This specific error message will always be split into two lines
        renderedMessage = (
            <>
                <p className="text-sm font-bold">Did you enter the wrong OTP?</p>
                <p className="text-sm mt-1 font-bold">Please check and re-enter.</p>
            </>
        );
    } else if (type === 'error' && message.includes("Please check and re-enter")) {
        // If an error message generally contains "Please check and re-enter",
        // we'll split it for better readability.
        // This assumes the main part of the message comes before "Please check and re-enter".
        const parts = message.split("Please check and re-enter");
        renderedMessage = (
            <>
                <p className="text-sm font-bold">{parts[0].trim()}</p>
                <p className="text-sm mt-1 font-bold">Please check and re-enter{parts[1] ? parts[1].trim() : ''}</p>
            </>
        );
    } else {
        // For all other messages, display as a single paragraph
        renderedMessage = <p className="text-sm font-bold">{message}</p>;
    }
    // --- END MODIFIED LOGIC ---


    return (
        <div
            className={`fixed top-4 right-4 ${bgColor} text-white rounded-lg p-4 shadow-lg max-w-xs w-full flex flex-col z-50 animate-slideInRight`}
            style={{ animation: 'slideInRight 0.5s forwards' }}
        >
            <div className="flex justify-between items-start mb-2">
                <div className="font-bold text-lg">{title}</div>
                <div className="flex-shrink-0 ml-2" style={{ width: '24px', height: '24px' }}>
                    {type === 'error' ? errorIcon : successIcon}
                </div>
            </div>
            <div className="flex-grow">
                {renderedMessage} {/* Use the new renderedMessage here */}
            </div>
            {/* REMOVED: The manual close button */}
            {/* <button
                onClick={() => { setIsVisible(false); if (onClose) onClose(); }}
                className="absolute top-1 right-1 text-white opacity-70 hover:opacity-100 text-lg px-2 py-1 rounded-full"
                aria-label="Close toast"
            >
                &times;
            </button> */}
            <style jsx>{`
                @keyframes slideInRight {
                    from {
                        transform: translateX(100%);
                        opacity: 0;
                    }
                    to {
                        transform: translateX(0);
                        opacity: 1;
                    }
                }
            `}</style>
        </div>
    );
}

export default ToastMessage;