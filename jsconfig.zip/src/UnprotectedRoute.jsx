import React from 'react';
import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from './Authcontext';

const UnprotectedRoute = () => {
    const { isAuthenticated, isLoading } = useAuth();
    if (isLoading) {
        return (
            <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black">
                <div className="spinner">
                    <div className="ball ball-1"></div>
                    <div className="ball ball-2"></div>
                    <div className="ball ball-3"></div>
                    <div className="ball ball-4"></div>
                    <div className="loading-text">Loading...</div>
                </div>
            </div>
        );
    }
    if (isAuthenticated) {
        return <Navigate to="/dashboard" replace />;
    }
    return <Outlet />;
};

export default UnprotectedRoute;